#!/bin/bash
# Installs Node.js dependencies and (optionally) a systemd service for the
# UDP Custom admin panel. Run as root on the same VPS as udp-custom.
set -e

if [[ "$(whoami)" != "root" ]]; then
  echo "Please run this as root: sudo ./install.sh"
  exit 1
fi

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js not found, installing Node 20.x..."
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi

echo "Installing npm dependencies..."
npm install --omit=dev

echo "Installing systemd service (port 2053)..."
cat > /etc/systemd/system/udp-panel.service <<EOF
[Unit]
Description=UDP Custom Admin Panel
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=$DIR
Environment=PORT=2053
ExecStart=$(command -v node) $DIR/server.js
Restart=always
RestartSec=2

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable udp-panel
systemctl restart udp-panel

sleep 1
echo ""
echo "Panel installed and started on port 2053."
echo "Check the admin password with:"
echo "  cat $DIR/data/INITIAL_ADMIN_PASSWORD.txt"
echo "Then open: http://<your-server-ip>:2053"
echo ""
echo "Logs: journalctl -u udp-panel -f"
