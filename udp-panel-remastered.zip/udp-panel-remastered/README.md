# UDP Custom (HTTP Custom) — Admin Panel

A self-hosted web dashboard for managing the SSH-tunnel accounts used by the
`udp-custom` service (the tool in the zip you shared). It manages real Linux
accounts using the **same conventions** as the bash menu that ships with
`udp-custom` (`module/udp`), so accounts you create from either tool stay in
sync:

- account: `useradd -M -s /bin/false -d /home/<user> <user>`
- expiry: `chage -E <date>`
- lock / unlock: `usermod -L` / `usermod -U`
- connection limit + display password: stored in the GECOS field as
  `<limit>,<password>`, exactly like the existing menu does.

## Requirements

- The VPS already running `udp-custom` (Ubuntu 20.04+, as in the zip's own README)
- Node.js 16+
- Root access (creating/locking system users requires it)

## Install

```bash
unzip udp-custom-panel.zip
cd udp-custom-panel
sudo ./install.sh
```

This installs dependencies, sets up a `udp-panel` systemd service on **port
2053**, and starts it.

To run it manually instead (e.g. for testing):

```bash
npm install
sudo PORT=2053 node server.js
```

## First login

On first start, a random 100-character admin password is generated and:

1. printed once in the console/log, and
2. saved to `data/INITIAL_ADMIN_PASSWORD.txt` (permissions `600`).

Copy it somewhere safe, then delete that file. You can set a new password
any time from **Settings → Change admin password** inside the panel.

Open `http://<your-server-ip>:2053` and log in with just that password —
there's no separate username, matching the "Admin" lock screen you asked for.

## What the panel does

- **Dashboard** — total users, how many are online right now, how many are
  blocked/expired, the server's public IP, live service status for
  `udp-custom`, `udpgw`, and SSH, plus a **System** panel with live CPU %,
  RAM used/total, and download/upload throughput (read straight from
  `/proc`, refreshed every few seconds).
- **Users** — searchable list of every tunnel account showing status
  (online/offline/blocked/expired), active connections vs. limit, expiry
  countdown, and a one-click **copy** chip with the exact
  `ip:1-65535@user:pass` string for pasting into HTTP Custom. The full
  string — including the password — now wraps instead of being clipped, so
  nothing is hidden when reading it off the screen to hand to a user.
  - **Add user**: username, password (or a generate button), expiry date,
    max connections.
  - **Edit / Block / Unblock / Delete** per account.
  - **Details** view with the full connect string.
- **Sessions** — a live terminal-style view listing every account with its
  current online/offline status and a running "connected now" count, updating
  automatically in the background (no manual refresh needed).
- **Settings** — change the admin password.

### What changed in this remaster

- Fixed the copy-chip CSS so the password portion of the connect string is
  never visually clipped.
- Replaced the raw `/etc/limit.log` viewer with a live per-user online/offline
  session monitor and a "connected now" count.
- Added CPU / RAM / network-throughput monitoring to the dashboard.
- Online/offline status now auto-refreshes every few seconds instead of only
  on page load, and connection detection has a fallback for systems where
  `ps -u <user>` doesn't return results.
- Fixed a UI glitch where every keystroke in the user search box fully
  re-rendered (and re-animated) the whole list — the search is now
  debounced, and the dashboard's card stagger animation was wired up
  correctly so cards cascade in smoothly instead of popping in together.

## Security notes (please read)

- This panel can create, delete, and lock real system accounts — treat the
  admin password like root access, because it effectively is.
- It's only served over plain HTTP. If this VPS is reachable from the
  internet on port 2053, put it behind a reverse proxy with TLS (e.g. Caddy
  or nginx + Let's Encrypt) rather than exposing it directly, or at minimum
  restrict port 2053 with a firewall rule to your own IP.
- Consider changing the default port and adding fail2ban / rate limiting on
  the login endpoint if the panel is internet-facing.
- The generated passwords are cryptographically random (Node's `crypto`
  module), not `Math.random()`.

## Project layout

```
server.js            Express app + routes
lib/auth.js           admin password hashing, sessions, random password generator
lib/sysUsers.js        Linux user management (useradd/chage/usermod/etc.)
lib/system.js         public IP lookup, systemd service status, log reader
public/               frontend (vanilla HTML/CSS/JS, no build step)
install.sh            installs deps + systemd service on port 2053
```
