const express = require('express');
const cookieParser = require('cookie-parser');
const path = require('path');

const auth = require('./lib/auth');
const sysUsers = require('./lib/sysUsers');
const system = require('./lib/system');

const PORT = process.env.PORT || 2053;

const app = express();
app.use(express.json());
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// --- First-run setup -------------------------------------------------------
const setup = auth.ensureAdminAccount();
if (setup.created) {
  console.log('================================================================');
  console.log(' UDP Custom Panel - first run detected');
  console.log(' A random admin password was generated:');
  console.log('');
  console.log(' ' + setup.password);
  console.log('');
  console.log(' It has also been saved to data/INITIAL_ADMIN_PASSWORD.txt');
  console.log(' Copy it somewhere safe, then delete that file.');
  console.log(' You can change the password later from the Settings page.');
  console.log('================================================================');
}

// --- Auth routes ------------------------------------------------------------
app.post('/api/login', (req, res) => {
  const { password } = req.body || {};
  if (!password || !auth.checkPassword(password)) {
    return res.status(401).json({ error: 'Incorrect password' });
  }
  const sid = auth.createSession();
  res.cookie(auth.SESSION_COOKIE, sid, {
    httpOnly: true,
    sameSite: 'lax',
    maxAge: 12 * 60 * 60 * 1000,
  });
  res.json({ ok: true });
});

app.post('/api/logout', (req, res) => {
  const sid = req.cookies[auth.SESSION_COOKIE];
  auth.destroySession(sid);
  res.clearCookie(auth.SESSION_COOKIE);
  res.json({ ok: true });
});

app.get('/api/session', (req, res) => {
  const sid = req.cookies[auth.SESSION_COOKIE];
  res.json({ authenticated: auth.isSessionValid(sid) });
});

// Everything below requires a valid session
app.use('/api', auth.requireAuth);

// --- Server info -------------------------------------------------------------
app.get('/api/server-info', async (req, res) => {
  const ip = await system.fetchPublicIp();
  res.json({ ip, services: system.getServices() });
});

app.get('/api/system-stats', (req, res) => {
  res.json(system.getSystemStats());
});

// --- User management ----------------------------------------------------------
app.get('/api/users', (req, res) => {
  try {
    res.json({ users: sysUsers.listUsers() });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/users/:username', (req, res) => {
  const user = sysUsers.getUser(req.params.username);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json({ user });
});

app.post('/api/users', (req, res) => {
  try {
    const { username, password, expiryDate, limit } = req.body || {};
    const user = sysUsers.createUser({
      username,
      password,
      expiryDate: expiryDate || null,
      limit: limit !== undefined ? Number(limit) : 1,
    });
    res.status(201).json({ user });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.put('/api/users/:username', (req, res) => {
  try {
    const { password, expiryDate, limit } = req.body || {};
    const user = sysUsers.updateUser(req.params.username, {
      password: password || undefined,
      expiryDate: expiryDate !== undefined ? expiryDate : undefined,
      limit: limit !== undefined ? Number(limit) : undefined,
    });
    res.json({ user });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.delete('/api/users/:username', (req, res) => {
  try {
    sysUsers.deleteUser(req.params.username);
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/users/:username/block', (req, res) => {
  try {
    sysUsers.blockUser(req.params.username);
    res.json({ user: sysUsers.getUser(req.params.username) });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/users/:username/unblock', (req, res) => {
  try {
    sysUsers.unblockUser(req.params.username);
    res.json({ user: sysUsers.getUser(req.params.username) });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/api/generate-password', (req, res) => {
  const length = Math.min(Math.max(Number(req.query.length) || 20, 4), 100);
  res.json({ password: auth.generateRandomPassword(length) });
});

// --- Settings ------------------------------------------------------------------
app.post('/api/settings/password', (req, res) => {
  const { currentPassword, newPassword } = req.body || {};
  if (!auth.checkPassword(currentPassword || '')) {
    return res.status(401).json({ error: 'Current password is incorrect' });
  }
  if (!newPassword || newPassword.length < 8) {
    return res.status(400).json({ error: 'New password must be at least 8 characters' });
  }
  auth.setPassword(newPassword);
  res.json({ ok: true });
});

app.listen(PORT, () => {
  console.log(`UDP Custom Panel listening on port ${PORT}`);
});
