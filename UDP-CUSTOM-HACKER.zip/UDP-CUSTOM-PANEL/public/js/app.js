const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

// Icon values are either a plain "d" path string (wrapped in <path> below),
// or raw multi-element SVG markup (used as-is) for icons made of several
// shapes — the bolt icon (single polygon) and terminal mark (chevron +
// underscore) below are examples of the latter.
const ICONS = {
  // Terminal prompt mark (">_") — replaces the old sakura blossom brand
  // icon. Built as filled shapes (not strokes) so it renders the same way
  // every other icon here does, via `fill: currentColor`.
  terminal: '<path d="M4.4 6.2a1 1 0 011.53-.85l7.6 4.8a1 1 0 010 1.7l-7.6 4.8A1 1 0 014.4 15.8V6.2z"/><rect x="13.4" y="16.6" width="7.2" height="2.1" rx="1"/>',
  eye: 'M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5C21.27 7.61 17 4.5 12 4.5zm0 12.5a5 5 0 110-10 5 5 0 010 10zm0-8a3 3 0 100 6 3 3 0 000-6z',
  edit: 'M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04a1 1 0 000-1.41l-2.34-2.34a1 1 0 00-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z',
  lock: 'M12 17a2 2 0 002-2 2 2 0 00-2-2 2 2 0 00-2 2 2 2 0 002 2zm6-9h-1V6a5 5 0 00-10 0v2H6a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V10a2 2 0 00-2-2zM9 6a3 3 0 016 0v2H9V6z',
  unlock: 'M12 17a2 2 0 002-2 2 2 0 00-2-2 2 2 0 00-2 2 2 2 0 002 2zm6-9h-9V6a3 3 0 016 0h2a5 5 0 00-10 0v2H6a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V10a2 2 0 00-2-2z',
  trash: 'M7 7h10l-.9 12.1a2 2 0 01-2 1.9H9.9a2 2 0 01-2-1.9L7 7zm3-3h4l1 2H9l1-2zM5 7h14',
  plus: 'M12 5v14M5 12h14',
  close: 'M6 6l12 12M18 6L6 18',
  check: 'M5 13l4 4L19 7',
  copy: 'M9 9h9v10H9zM6 6h9v1.6H8.4A1.8 1.8 0 006.6 9.4V17H5V6z',
  power: 'M13 3h-2v10h2V3zm4.83 2.17l-1.42 1.42A6.92 6.92 0 0119 12a7 7 0 11-11.66-5.24L5.92 5.34A9 9 0 1017.83 5.17z',
  users: 'M12 12a5 5 0 100-10 5 5 0 000 10zm0 2c-4.4 0-9 2.2-9 5.5V22h18v-2.5c0-3.3-4.6-5.5-9-5.5z',
  bolt: '<polygon points="13,2 4,15 11,15 10,22 20,9 13,9"/>',
};

function svg(name, cls) {
  const body = ICONS[name] || '';
  const inner = body.trim().startsWith('<') ? body : `<path d="${body}"/>`;
  return `<svg viewBox="0 0 24 24" class="${cls || ''}">${inner}</svg>`;
}

// ---------------------------------------------------------------------------
// Matrix digital rain — พื้นหลังตัวเลข 0/1 ไหลลงมา วาดด้วย Canvas 2D ล้วน
// ไม่มีไฟล์ภาพ ใช้เทคนิค column-based fade แบบมาตรฐาน (เร็วกว่าระบบ
// particle เดิมมาก): แต่ละคอลัมน์จำแค่ "แถวปัจจุบัน" ตัวเดียว ไม่ต้องเก็บ
// array ของอนุภาคหลายร้อยชิ้นเหมือนฝนกลีบซากุระเดิม — ต้นทุนต่อเฟรมคือ
// fillRect โปร่งใส 1 ครั้ง + fillText 1 ครั้งต่อคอลัมน์เท่านั้น
// ---------------------------------------------------------------------------
(function digitalRain() {
  const canvas = $('#matrixRain');
  const ctx = canvas.getContext('2d');
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let w, h, dpr, cols = 0, drops = [], raf = null, lastT = 0;

  // ปรับค่าตรงนี้ได้ง่ายๆ ถ้าอยากให้ฝนถี่/โปร่ง/เร็วกว่าเดิม
  const FONT_SIZE = 15;               // px ต่อคอลัมน์/แถว
  const FRAME_MS = 1000 / 24;         // จำกัดเฟรมเรตไว้ ~24fps พอสำหรับตาเห็นลื่น แต่ประหยัด CPU/แบตกว่า 60fps มาก
  const FADE_ALPHA = 0.11;            // ยิ่งค่าน้อย หางฝนยิ่งยาว/จางช้า
  const RESET_CHANCE = 0.975;         // โอกาสที่คอลัมน์จะ "จบเที่ยว" แล้วเริ่มใหม่จากบนสุดในแต่ละเฟรม (สุ่มความยาวสายฝน)
  const HEAD_COLOR = '#eafff2';       // ตัวอักษรหัวขบวน (สว่างสุด, ใกล้ขาว)
  const TAIL_COLOR = 'rgba(45,255,140,0.75)'; // ตัวอักษรตามหลัง (เขียวเข้ม)

  function resize() {
    dpr = Math.min(window.devicePixelRatio || 1, 1.5); // เพดาน dpr ต่ำกว่าจอปกติเพื่อลดพื้นที่วาดบนมือถือจอละเอียดสูง
    w = window.innerWidth; h = window.innerHeight;
    canvas.width = w * dpr; canvas.height = h * dpr;
    canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    cols = Math.ceil(w / FONT_SIZE);
    // คงตำแหน่งคอลัมน์เดิมไว้เท่าที่ทำได้เมื่อ resize แทนที่จะรีเซตฝนทั้งจอ
    const next = new Array(cols);
    for (let i = 0; i < cols; i++) next[i] = drops[i] !== undefined ? drops[i] : -Math.floor(Math.random() * (h / FONT_SIZE));
    drops = next;
    ctx.font = `${FONT_SIZE}px ${getComputedStyle(document.body).getPropertyValue('--font-mono') || 'monospace'}`;
    ctx.textBaseline = 'top';
    // วาดพื้นทึบครั้งแรกกันจอกระพริบขาวตอนโหลด (ปกติ trail อาศัยเฟรมก่อนหน้าซึ่งยังไม่มี)
    ctx.fillStyle = '#050a07';
    ctx.fillRect(0, 0, w, h);
  }

  function drawFrame() {
    // เบลอ/จางเฟรมก่อนหน้าแทนการ clearRect ล้วนๆ — คือเทคนิคที่ทำให้เกิด
    // "หาง" ของตัวเลขที่ไหลลงมา โดยไม่ต้องเก็บ state ของหางเอง
    ctx.fillStyle = `rgba(5,10,7,${FADE_ALPHA})`;
    ctx.fillRect(0, 0, w, h);

    for (let i = 0; i < cols; i++) {
      const char = Math.random() < 0.5 ? '0' : '1';
      const x = i * FONT_SIZE;
      const y = drops[i] * FONT_SIZE;

      if (y >= 0 && y < h + FONT_SIZE) {
        ctx.fillStyle = HEAD_COLOR;
        ctx.fillText(char, x, y);
        // ตัวอักษรก่อนหน้าหนึ่งแถว วาดซ้ำด้วยสีเขียวเข้มกว่า ให้หัวขบวนเด่นออกมาจากหาง
        ctx.fillStyle = TAIL_COLOR;
        ctx.fillText(Math.random() < 0.5 ? '0' : '1', x, y - FONT_SIZE);
      }

      drops[i]++;
      if (y > h && Math.random() > RESET_CHANCE) drops[i] = 0;
    }
  }

  function loop(t) {
    raf = requestAnimationFrame(loop);
    if (t - lastT < FRAME_MS) return; // throttle: ข้ามเฟรมถ้ายังไม่ถึงรอบ
    lastT = t;
    drawFrame();
  }
  function start() {
    if (raf) return;
    lastT = 0;
    raf = requestAnimationFrame(loop);
  }
  function stop() {
    if (raf) cancelAnimationFrame(raf);
    raf = null;
  }

  resize();
  window.addEventListener('resize', resize, { passive: true });
  document.addEventListener('visibilitychange', () => {
    if (reduced) return;
    document.hidden ? stop() : start(); // หยุดวาดทั้งหมดเมื่อสลับแท็บ/พับแอป ไม่กิน CPU เปล่าๆ เบื้องหลัง
  });

  if (reduced) {
    // เคารพ prefers-reduced-motion: วาดเฟรมนิ่งเฟรมเดียว ไม่มีลูปแอนิเมชันต่อ
    drawFrame();
  } else {
    start();
  }
})();

// ---------------------------------------------------------------------------
// Ripple + haptics
// ---------------------------------------------------------------------------
document.addEventListener('pointerdown', (e) => {
  const btn = e.target.closest('button');
  if (!btn || btn.disabled) return;
  const rect = btn.getBoundingClientRect();
  const size = Math.max(rect.width, rect.height) * 1.4;
  const ripple = document.createElement('span');
  ripple.className = 'ripple';
  ripple.style.width = ripple.style.height = size + 'px';
  ripple.style.left = e.clientX - rect.left - size / 2 + 'px';
  ripple.style.top = e.clientY - rect.top - size / 2 + 'px';
  btn.appendChild(ripple);
  setTimeout(() => ripple.remove(), 600);
});

function haptic(ms = 8) {
  if (navigator.vibrate) navigator.vibrate(ms);
}

// ---------------------------------------------------------------------------
// Toast
// ---------------------------------------------------------------------------
function toast(msg, isError = false, duration = 2600) {
  const el = $('#toast');
  el.innerHTML = `<div class="toast-bar" style="animation-duration:${duration}ms"></div>${svg(isError ? 'close' : 'check')}<span>${msg}</span>`;
  el.classList.toggle('err', isError);
  void el.offsetWidth;
  el.classList.add('show');
  haptic(isError ? [10, 30, 10] : 8);
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.remove('show'), duration);
}

// ---------------------------------------------------------------------------
// Animated counters
// ---------------------------------------------------------------------------
function animateValue(el, to) {
  el.classList.remove('skeleton');
  const from = 0;
  const dur = 700;
  const start = performance.now();
  function step(t) {
    const p = Math.min((t - start) / dur, 1);
    const eased = 1 - Math.pow(1 - p, 3);
    el.textContent = Math.round(from + (to - from) * eased);
    if (p < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

const THAI_WEEKDAYS = ['วันอาทิตย์', 'วันจันทร์', 'วันอังคาร', 'วันพุธ', 'วันพฤหัสบดี', 'วันศุกร์', 'วันเสาร์'];
const THAI_MONTHS = ['มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน', 'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'];
function thaiDateString(d = new Date()) {
  return `${THAI_WEEKDAYS[d.getDay()]}ที่ ${d.getDate()} ${THAI_MONTHS[d.getMonth()]} ${d.getFullYear() + 543}`;
}

// ---------------------------------------------------------------------------
// Bottom sheets
// ---------------------------------------------------------------------------
function openSheet(id) {
  const el = $('#' + id);
  el.hidden = false;
  void el.offsetWidth;
  el.classList.add('open');
  haptic(6);
}
function closeSheet(id) {
  const el = $('#' + id);
  el.classList.remove('open');
  setTimeout(() => (el.hidden = true), 450);
}
$$('[data-drag]').forEach((handle) => {
  const id = handle.dataset.drag;
  const sheetEl = $('#' + id).querySelector('.sheet');
  let startY = 0, dy = 0, dragging = false;
  handle.addEventListener('touchstart', (e) => {
    startY = e.touches[0].clientY;
    dragging = true;
    sheetEl.classList.add('dragging');
  }, { passive: true });
  handle.addEventListener('touchmove', (e) => {
    if (!dragging) return;
    dy = Math.max(0, e.touches[0].clientY - startY);
    sheetEl.style.transform = `translateY(${dy}px)`;
  }, { passive: true });
  handle.addEventListener('touchend', () => {
    dragging = false;
    sheetEl.classList.remove('dragging');
    sheetEl.style.transform = '';
    if (dy > 110) closeSheet(id);
    dy = 0;
  });
});

// ---------------------------------------------------------------------------
// API helper
// ---------------------------------------------------------------------------
async function api(path, options = {}) {
  const res = await fetch('/api' + path, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  let body = null;
  try { body = await res.json(); } catch {}
  if (!res.ok) {
    const err = new Error((body && body.error) || `Request failed (${res.status})`);
    err.status = res.status;
    err.body = body;
    throw err;
  }
  return body;
}

let serverIp = '';
let usersCache = [];
let usersFilterExpired = false;

// ---------------------------------------------------------------------------
// Auth / boot
// ---------------------------------------------------------------------------
async function boot() {
  $('#loginBrandMark').innerHTML = svg('terminal');
  $('#topbarBrandMark').innerHTML = svg('terminal');
  $('#logoutBtn').innerHTML = svg('power');
  $('#addUserIcon').innerHTML = svg('plus');
  $('#fastUserIcon').innerHTML = svg('bolt');
  $('#closeModal').innerHTML = svg('close');
  $('#closeDetailModal').innerHTML = svg('close');
  $('#closeManualCopy').innerHTML = svg('close');

  try {
    const { authenticated } = await api('/session');
    if (authenticated) return showApp();
  } catch {}
  showLogin();
}

function showLogin() {
  $('#loginView').hidden = false;
  $('#appView').hidden = true;
}

async function showApp() {
  $('#loginView').hidden = true;
  $('#appView').hidden = false;
  initNavIndicator();
  await refreshServerInfo();
  await refreshUsers();
  renderDashboard();
  startPolling();
}

// รีเฟรชรายชื่อผู้ใช้/สถานะบล็อก-หมดอายุเป็นระยะ โดยไม่ต้องออกจากหน้าแล้วกลับเข้ามาใหม่
let pollTimer = null;
let pollBusy = false;
function startPolling() {
  if (pollTimer) return;
  pollTimer = setInterval(pollTick, 7000);
}
function stopPolling() {
  if (pollTimer) clearInterval(pollTimer);
  pollTimer = null;
}
async function pollTick() {
  if (document.hidden || $('#appView').hidden || pollBusy) return;
  pollBusy = true;
  try {
    await refreshServerInfo();
    await refreshUsers();
    const activeView = $('.view.active');
    if (activeView && activeView.id === 'view-dashboard') renderDashboard();
    if (activeView && activeView.id === 'view-users') renderUsersList(false);
  } catch (err) {
    if (err.message === 'unauthorized') {
      stopPolling();
      stopMonitorPolling();
      showLogin();
    }
    // otherwise a transient network hiccup — just try again on the next tick
  } finally {
    pollBusy = false;
  }
}
document.addEventListener('visibilitychange', () => {
  if (document.hidden) return; // interval body already no-ops while hidden
  if (!$('#appView').hidden) pollTick(); // catch up immediately on return
});

let loginLockTimer = null;

// Disables the password field + submit button and ticks a live mm:ss
// countdown in the error slot until the server-side lockout (10 wrong
// attempts from this IP) expires, then re-enables the form automatically.
function startLoginLockCountdown(remainingMs) {
  const errEl = $('#loginError');
  const btn = $('#loginBtn');
  const input = $('#adminPassword');
  clearInterval(loginLockTimer);

  let msLeft = remainingMs;
  input.disabled = true;
  btn.disabled = true;

  const tick = () => {
    if (msLeft <= 0) {
      clearInterval(loginLockTimer);
      loginLockTimer = null;
      input.disabled = false;
      btn.disabled = false;
      errEl.hidden = true;
      return;
    }
    const mm = Math.floor(msLeft / 60000);
    const ss = Math.floor((msLeft % 60000) / 1000).toString().padStart(2, '0');
    errEl.textContent = `กรอกรหัสผ่านผิดครบ 10 ครั้ง กรุณารออีก ${mm}:${ss}`;
    errEl.hidden = false;
    msLeft -= 1000;
  };

  tick();
  loginLockTimer = setInterval(tick, 1000);
}

$('#loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = $('#loginBtn');
  const password = $('#adminPassword').value;
  const errEl = $('#loginError');
  errEl.hidden = true;
  btn.disabled = true;
  const original = btn.textContent;
  btn.innerHTML = '<span class="spinner"></span>กำลังปลดล็อก…';
  try {
    await api('/login', { method: 'POST', body: JSON.stringify({ password }) });
    $('#adminPassword').value = '';
    await showApp();
  } catch (err) {
    if (err.status === 429 && err.body && err.body.lockedForMs) {
      startLoginLockCountdown(err.body.lockedForMs);
    } else {
      errEl.textContent = err.message;
      errEl.hidden = false;
    }
    haptic([10, 30, 10]);
  } finally {
    btn.disabled = !!loginLockTimer;
    btn.textContent = original;
  }
});

$('#logoutBtn').addEventListener('click', async () => {
  stopPolling();
  stopMonitorPolling();
  await api('/logout', { method: 'POST' });
  showLogin();
});

// ---------------------------------------------------------------------------
// Navigation
// ---------------------------------------------------------------------------
const VIEW_TITLES = { dashboard: 'หน้าแรก', users: 'ผู้ใช้งาน', monitor: 'ตรวจสอบระบบ', settings: 'ตั้งค่า' };

function initNavIndicator() {
  const active = $('.nav-tab.active') || $('.nav-tab');
  moveIndicator(active);
}
function moveIndicator(btn) {
  const ind = $('#navIndicator');
  const nav = $('.bottom-nav');
  const navRect = nav.getBoundingClientRect();
  const rect = btn.getBoundingClientRect();
  ind.style.width = rect.width + 'px';
  ind.style.transform = `translateX(${rect.left - navRect.left}px)`;
}
window.addEventListener('resize', () => {
  const active = $('.nav-tab.active');
  if (active && !$('#appView').hidden) moveIndicator(active);
}, { passive: true });

$$('.nav-tab').forEach((btn) => {
  btn.addEventListener('click', () => {
    usersFilterExpired = false;
    switchView(btn.dataset.view, btn);
  });
});
$$('[data-goto]').forEach((btn) =>
  btn.addEventListener('click', () => {
    usersFilterExpired = btn.dataset.filter === 'expired';
    switchView(btn.dataset.goto, $(`.nav-tab[data-view="${btn.dataset.goto}"]`));
  })
);

function switchView(name, btn) {
  $$('.nav-tab').forEach((b) => b.classList.toggle('active', b.dataset.view === name));
  if (btn) moveIndicator(btn);
  $$('.view').forEach((v) => v.classList.remove('active'));
  const target = $(`#view-${name}`);
  void target.offsetWidth;
  target.classList.add('active');
  $('#topbarTitle').textContent = VIEW_TITLES[name] || '';
  if (name === 'monitor') {
    loadLogs();
    startMonitorPolling();
  } else {
    stopMonitorPolling();
  }
  if (name === 'users') renderUsersList();
  haptic(6);
}

// ---------------------------------------------------------------------------
// Server info / dashboard
// ---------------------------------------------------------------------------
async function refreshServerInfo() {
  try {
    const info = await api('/server-info');
    serverIp = info.ip || '—';
    const el = $('#statIp');
    el.classList.remove('skeleton');
    el.textContent = serverIp;
  } catch {
    const el = $('#statIp');
    el.classList.remove('skeleton');
    el.textContent = '—';
  }
}

async function refreshUsers() {
  const { users } = await api('/users');
  usersCache = users;
}

function renderDashboard() {
  const total = usersCache.length;
  const blocked = usersCache.filter((u) => u.status === 'blocked' || u.status === 'expired').length;
  animateValue($('#statTotal'), total);
  animateValue($('#statBlocked'), blocked);

  const dateEl = $('#statToday');
  dateEl.classList.remove('skeleton');
  dateEl.textContent = thaiDateString();

  const expiredSorted = usersCache
    .filter((u) => u.expired && u.expiryDate)
    .sort((a, b) => (a.expiryDate < b.expiryDate ? 1 : a.expiryDate > b.expiryDate ? -1 : 0))
    .slice(0, 3);

  if (!expiredSorted.length) {
    $('#recentUsers').innerHTML = '<div class="empty-state">ยังไม่มีบัญชีที่หมดอายุ</div>';
  } else {
    $('#recentUsers').innerHTML = usersListHtml(expiredSorted, { compact: true });
    bindCardActions($('#recentUsers'));
  }
}

// ---------------------------------------------------------------------------
// Users view
// ---------------------------------------------------------------------------
$('#userSearch').addEventListener('input', () => renderUsersList(false));
$('#clearExpiredFilter').addEventListener('click', () => {
  usersFilterExpired = false;
  renderUsersList(false);
});

async function renderUsersList(refetch = true) {
  if (refetch) await refreshUsers();
  $('#expiredFilterBanner').hidden = !usersFilterExpired;
  const q = $('#userSearch').value.trim().toLowerCase();
  let filtered = usersCache;
  if (usersFilterExpired) filtered = filtered.filter((u) => u.expired);
  if (q) filtered = filtered.filter((u) => u.username.toLowerCase().includes(q));
  $('#usersList').innerHTML = usersListHtml(filtered, { compact: false });
  bindCardActions($('#usersList'));
}

function statusBadge(u) {
  if (u.status === 'blocked') return '<span class="badge badge-blocked">บล็อก</span>';
  if (u.status === 'expired') return '<span class="badge badge-expired">หมดอายุ</span>';
  return '';
}

function connectString(u) {
  const ip = serverIp || 'YOUR.SERVER.IP';
  return `${ip}:1-65535@${u.username}:${u.password || ''}`;
}

function usersListHtml(users, { compact }) {
  if (!users.length) {
    return `<div class="empty-state">${svg('users')}<div>ยังไม่มีบัญชี${compact ? '' : ' กดปุ่ม “เพิ่มผู้ใช้” ด้านบนเพื่อสร้างบัญชีแรก'}</div></div>`;
  }
  return users
    .map((u, i) => {
      const expiry = u.expiryDate ? `${u.expiryDate} · ${u.daysLeft >= 0 ? 'เหลือ ' + u.daysLeft + ' วัน' : 'หมดอายุแล้ว'}` : 'ไม่มีวันหมดอายุ';
      const connCol = `เชื่อมต่อได้สูงสุด ${u.limit || '∞'}`;
      const initials = u.username.slice(0, 2).toUpperCase();
      const actions = compact
        ? ''
        : `<div class="user-card-actions">
            <button class="icon-btn" data-action="view" data-user="${u.username}" aria-label="รายละเอียด">${svg('eye')}</button>
            <button class="icon-btn" data-action="edit" data-user="${u.username}" aria-label="แก้ไข">${svg('edit')}</button>
            ${
              u.status === 'blocked'
                ? `<button class="icon-btn on-green" data-action="unblock" data-user="${u.username}" aria-label="ปลดบล็อก">${svg('unlock')}</button>`
                : `<button class="icon-btn on-accent" data-action="block" data-user="${u.username}" aria-label="บล็อก">${svg('lock')}</button>`
            }
            <button class="icon-btn on-danger" data-action="delete" data-user="${u.username}" aria-label="ลบ">${svg('trash')}</button>
          </div>`;
      return `<div class="user-card" style="animation-delay:${Math.min(i * 40, 400)}ms">
        <div class="user-card-top">
          <div class="user-card-id">
            <div class="user-avatar">${initials}</div>
            <span class="user-card-name">${u.username}</span>
          </div>
          ${statusBadge(u)}
        </div>
        <div class="user-card-meta"><span>${connCol}</span><span>${expiry}</span></div>
        <span class="copy-chip" data-action="copy" data-copy="${connectString(u)}">
          <span class="txt">${connectString(u)}</span>${svg('copy')}
        </span>
        ${actions}
      </div>`;
    })
    .join('');
}

function bindCardActions(root) {
  $$('[data-action="copy"]', root).forEach((el) => el.addEventListener('click', () => copyToClipboard(el)));
  $$('[data-action="view"]', root).forEach((el) => el.addEventListener('click', () => openDetail(el.dataset.user)));
  $$('[data-action="edit"]', root).forEach((el) => el.addEventListener('click', () => openUserModal(el.dataset.user)));
  $$('[data-action="block"]', root).forEach((el) => el.addEventListener('click', () => toggleBlock(el.dataset.user, true)));
  $$('[data-action="unblock"]', root).forEach((el) => el.addEventListener('click', () => toggleBlock(el.dataset.user, false)));
  $$('[data-action="delete"]', root).forEach((el) => el.addEventListener('click', () => deleteUser(el.dataset.user)));
}

// Tries, in order: the modern async Clipboard API (only works in a secure
// context — HTTPS or localhost — which this panel isn't by default), then
// the legacy execCommand trick (works over plain HTTP in effectively every
// mobile browser/WebView), and resolves false if neither actually wrote
// anything so the caller can fall back to a manual copy.
async function tryCopyText(text) {
  if (window.isSecureContext && navigator.clipboard && navigator.clipboard.writeText) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      // fall through to the legacy method below
    }
  }
  try {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.position = 'fixed';
    ta.style.top = '-9999px';
    ta.style.left = '-9999px';
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    ta.setSelectionRange(0, text.length);
    const ok = document.execCommand('copy');
    document.body.removeChild(ta);
    if (ok) return true;
  } catch {
    // fall through to manual copy
  }
  return false;
}

async function copyToClipboard(el) {
  const text = el.dataset.copy;
  const ok = await tryCopyText(text);
  if (ok) {
    el.classList.add('copied');
    haptic(10);
    setTimeout(() => el.classList.remove('copied'), 1400);
  } else {
    haptic([10, 30, 10]);
    openManualCopy(text);
  }
}

// Last-resort path when the browser/WebView blocks programmatic copying
// entirely (some in-app browsers do). Shows the full string in a selected,
// read-only field so the user can long-press → Copy themselves.
function openManualCopy(text) {
  const input = $('#manualCopyText');
  input.value = text;
  openSheet('manualCopySheet');
  setTimeout(() => {
    input.focus();
    input.select();
    input.setSelectionRange(0, text.length);
  }, 320);
}
$('#closeManualCopy').addEventListener('click', () => closeSheet('manualCopySheet'));
$('#manualCopySheet').addEventListener('click', (e) => {
  if (e.target.id === 'manualCopySheet') closeSheet('manualCopySheet');
});
$('#manualCopyText').addEventListener('click', function () {
  this.select();
  this.setSelectionRange(0, this.value.length);
});

async function toggleBlock(username, block) {
  try {
    await api(`/users/${encodeURIComponent(username)}/${block ? 'block' : 'unblock'}`, { method: 'POST' });
    toast(block ? `บล็อก ${username} แล้ว` : `ปลดบล็อก ${username} แล้ว`);
    await renderUsersList();
    renderDashboard();
  } catch (err) {
    toast(err.message, true);
  }
}

async function deleteUser(username) {
  if (!confirm(`ลบบัญชี "${username}"? การกระทำนี้ไม่สามารถย้อนกลับได้`)) return;
  try {
    await api(`/users/${encodeURIComponent(username)}`, { method: 'DELETE' });
    toast(`ลบ ${username} แล้ว`);
    await renderUsersList();
    renderDashboard();
  } catch (err) {
    toast(err.message, true);
  }
}

// ---------------------------------------------------------------------------
// Detail sheet
// ---------------------------------------------------------------------------
function openDetail(username) {
  const u = usersCache.find((x) => x.username === username);
  if (!u) return;
  const expiry = u.expiryDate ? `${u.expiryDate} (${u.daysLeft >= 0 ? 'เหลือ ' + u.daysLeft + ' วัน' : 'หมดอายุแล้ว'})` : 'ไม่มีวันหมดอายุ';
  $('#detailBody').innerHTML = `
    <div class="row"><span>ชื่อผู้ใช้</span><span>${u.username}</span></div>
    <div class="row"><span>รหัสผ่าน</span><span>${u.password || '—'}</span></div>
    <div class="row"><span>สถานะ</span><span>${statusBadge(u) || 'ใช้งานได้ปกติ'}</span></div>
    <div class="row"><span>เชื่อมต่อได้สูงสุด</span><span>${u.limit || '∞'}</span></div>
    <div class="row"><span>วันหมดอายุ</span><span>${expiry}</span></div>
    <span class="copy-chip" data-action="copy" data-copy="${connectString(u)}" style="margin-top:12px">
      <span class="txt">${connectString(u)}</span>${svg('copy')}
    </span>
  `;
  bindCardActions($('#detailBody'));
  openSheet('detailSheet');
}
$('#closeDetailModal').addEventListener('click', () => closeSheet('detailSheet'));
$('#detailSheet').addEventListener('click', (e) => {
  if (e.target.id === 'detailSheet') closeSheet('detailSheet');
});

// ---------------------------------------------------------------------------
// Add / edit user sheet
// ---------------------------------------------------------------------------
$('#openAddUser').addEventListener('click', () => openUserModal(null));
$('#closeModal').addEventListener('click', closeUserModal);
$('#cancelUserBtn').addEventListener('click', closeUserModal);
$('#userSheet').addEventListener('click', (e) => {
  if (e.target.id === 'userSheet') closeUserModal();
});

function openUserModal(username) {
  const editing = !!username;
  $('#modalTitle').textContent = editing ? `แก้ไข ${username}` : 'เพิ่มผู้ใช้';
  $('#editUsername').value = username || '';
  $('#fUsername').value = username || '';
  $('#fUsername').disabled = editing;
  $('#modalError').hidden = true;

  if (editing) {
    const u = usersCache.find((x) => x.username === username);
    $('#fPassword').value = u.password || '';
    $('#fExpiry').value = u.expiryDate || '';
    $('#fLimit').value = u.limit || 1;
  } else {
    $('#fPassword').value = '';
    $('#fExpiry').value = '';
    $('#fLimit').value = 1;
  }
  openSheet('userSheet');
}

function closeUserModal() {
  closeSheet('userSheet');
  $('#userForm').reset();
  $('#fUsername').disabled = false;
}

$('#fGenPass').addEventListener('click', async () => {
  const { password } = await api('/generate-password?length=20');
  $('#fPassword').value = password;
  haptic(8);
});

$('#userForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const editing = $('#editUsername').value;
  const payload = {
    username: $('#fUsername').value.trim(),
    password: $('#fPassword').value,
    expiryDate: $('#fExpiry').value || null,
    limit: Number($('#fLimit').value) || 1,
  };
  const errEl = $('#modalError');
  errEl.hidden = true;
  try {
    if (editing) {
      await api(`/users/${encodeURIComponent(editing)}`, { method: 'PUT', body: JSON.stringify(payload) });
      toast(`แก้ไข ${editing} แล้ว`);
    } else {
      await api('/users', { method: 'POST', body: JSON.stringify(payload) });
      toast(`สร้าง ${payload.username} สำเร็จ`);
    }
    closeUserModal();
    await renderUsersList();
    renderDashboard();
  } catch (err) {
    errEl.textContent = err.message;
    errEl.hidden = false;
    haptic([10, 30, 10]);
  }
});

// ---------------------------------------------------------------------------
// Fast User — สร้างบัญชี lookkhaNN แบบกดปุ่มเดียวจบ
// ---------------------------------------------------------------------------
$('#openFastUser').addEventListener('click', async () => {
  const btn = $('#openFastUser');
  btn.disabled = true;
  try {
    const { user } = await api('/users/fast', { method: 'POST' });
    toast(`สร้าง ${user.username} สำเร็จ · รหัสผ่าน ${user.password}`, false, 5000);
    await renderUsersList();
    renderDashboard();
  } catch (err) {
    toast(err.message, true);
  } finally {
    btn.disabled = false;
  }
});

// ---------------------------------------------------------------------------
// ตรวจสอบระบบ: เน็ต / CPU / RAM + บันทึกลิมิตเตอร์
// ---------------------------------------------------------------------------
async function loadLogs() {
  const { log } = await api('/logs');
  $('#logOutput').textContent = log && log.trim() ? log : 'ยังไม่มีเหตุการณ์ที่บันทึกไว้';
}

let monitorTimer = null;
async function loadSystemStats() {
  try {
    const { net, cpuPercent, mem } = await api('/system-stats');
    $('#statNetDown').textContent = net.rxMbps.toFixed(1);
    $('#statNetUp').textContent = net.txMbps.toFixed(1);
    $('#cpuBar').style.width = cpuPercent + '%';
    $('#cpuLabel').textContent = cpuPercent + '%';
    const fmt = (mb) => (mb >= 1024 ? (mb / 1024).toFixed(1) + ' GB' : Math.round(mb) + ' MB');
    const pct = mem.totalMb ? Math.round((mem.usedMb / mem.totalMb) * 100) : 0;
    $('#ramBar').style.width = pct + '%';
    $('#ramLabel').textContent = `${fmt(mem.usedMb)} / ${fmt(mem.totalMb)}`;
  } catch {
    // transient error — the next 3s tick will retry
  }
}
function startMonitorPolling() {
  loadSystemStats();
  if (monitorTimer) return;
  monitorTimer = setInterval(loadSystemStats, 3000);
}
function stopMonitorPolling() {
  if (monitorTimer) clearInterval(monitorTimer);
  monitorTimer = null;
}

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------
$('#genPassBtn').addEventListener('click', async () => {
  const { password } = await api('/generate-password?length=24');
  $('#newPass').value = password;
  haptic(8);
});

$('#passwordForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const msgEl = $('#settingsMsg');
  try {
    await api('/settings/password', {
      method: 'POST',
      body: JSON.stringify({ currentPassword: $('#curPass').value, newPassword: $('#newPass').value }),
    });
    msgEl.textContent = 'อัปเดตรหัสผ่านแล้ว';
    msgEl.style.color = 'var(--green)';
    $('#passwordForm').reset();
    toast('อัปเดตรหัสผ่านแล้ว');
  } catch (err) {
    msgEl.textContent = err.message;
    msgEl.style.color = 'var(--red)';
    haptic([10, 30, 10]);
  }
});

boot();
