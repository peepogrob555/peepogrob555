const express = require('express');
const cookieParser = require('cookie-parser');
const path = require('path');

const auth = require('./lib/auth');
const sysUsers = require('./lib/sysUsers');
const system = require('./lib/system');

const PORT = process.env.PORT || 2053;

const app = express();
app.use(express.json());
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// --- First-run setup -------------------------------------------------------
const setup = auth.ensureAdminAccount();
if (setup.created) {
  console.log('================================================================');
  console.log(' UDP Custom Panel - first run detected');
  console.log(' A random admin password was generated:');
  console.log('');
  console.log(' ' + setup.password);
  console.log('');
  console.log(' It has also been saved to data/INITIAL_ADMIN_PASSWORD.txt');
  console.log(' Copy it somewhere safe, then delete that file.');
  console.log(' You can change the password later from the Settings page.');
  console.log('================================================================');
}

// --- Auth routes ------------------------------------------------------------
// Note: req.ip is the direct TCP peer address. That's correct for the
// default install (Node listens directly on :2053, see install.sh) — but if
// this ever ends up behind a reverse proxy (nginx, Cloudflare, etc.), every
// request will appear to come from the proxy's IP unless you both set
// `app.set('trust proxy', ...)` to a specific proxy address and have that
// proxy actually set X-Forwarded-For. Trusting it blindly with no proxy in
// front would let anyone bypass the lockout below just by sending their own
// X-Forwarded-For header, so it's left off by default.
app.post('/api/login', (req, res) => {
  const ip = req.ip;
  const { locked, remainingMs } = auth.getLoginLockState(ip);
  if (locked) {
    const mins = Math.ceil(remainingMs / 60000);
    return res.status(429).json({
      error: `กรอกรหัสผ่านผิดครบ 10 ครั้ง กรุณารออีกประมาณ ${mins} นาทีแล้วลองใหม่`,
      lockedForMs: remainingMs,
    });
  }

  const { password } = req.body || {};
  if (!password || !auth.checkPassword(password)) {
    auth.recordFailedLogin(ip);
    return res.status(401).json({ error: 'รหัสผ่านไม่ถูกต้อง' });
  }

  auth.recordSuccessfulLogin(ip);
  const sid = auth.createSession();
  res.cookie(auth.SESSION_COOKIE, sid, {
    httpOnly: true,
    sameSite: 'lax',
    maxAge: 12 * 60 * 60 * 1000,
  });
  res.json({ ok: true });
});

app.post('/api/logout', (req, res) => {
  const sid = req.cookies[auth.SESSION_COOKIE];
  auth.destroySession(sid);
  res.clearCookie(auth.SESSION_COOKIE);
  res.json({ ok: true });
});

app.get('/api/session', (req, res) => {
  const sid = req.cookies[auth.SESSION_COOKIE];
  res.json({ authenticated: auth.isSessionValid(sid) });
});

// Everything below requires a valid session
app.use('/api', auth.requireAuth);

// --- Server info -------------------------------------------------------------
app.get('/api/server-info', async (req, res) => {
  const ip = await system.fetchPublicIp();
  res.json({ ip });
});

app.get('/api/logs', (req, res) => {
  res.json({ log: system.getLimiterLog() });
});

// เน็ต (Mbps) / CPU % / RAM สำหรับหน้า "ตรวจสอบระบบ" — ทุกค่าอ่านสดจากเครื่องจริง
app.get('/api/system-stats', (req, res) => {
  res.json({
    net: system.getNetworkMbps(),
    cpuPercent: system.getCpuPercent(),
    mem: system.getMemory(),
  });
});

// --- User management ----------------------------------------------------------
app.get('/api/users', (req, res) => {
  try {
    res.json({ users: sysUsers.listUsers() });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/users/:username', (req, res) => {
  try {
    const user = sysUsers.getUser(req.params.username);
    if (!user) return res.status(404).json({ error: 'ไม่พบผู้ใช้นี้' });
    res.json({ user });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/users', (req, res) => {
  try {
    const { username, password, expiryDate, limit } = req.body || {};
    const user = sysUsers.createUser({
      username,
      password,
      expiryDate: expiryDate || null,
      limit: limit !== undefined ? Number(limit) : 1,
    });
    res.status(201).json({ user });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Fast User: one tap = one account, "lookkhaNN" (gaps filled first), a
// 4-digit numeric password, limit 1 (1 user = 1 device/IP), expiry = today
// + 30 days.
app.post('/api/users/fast', (req, res) => {
  try {
    const username = sysUsers.nextFastUserUsername();
    if (!username) {
      return res.status(400).json({ error: 'ใช้ครบ lookkha01–99 แล้ว ไม่มีลำดับว่าง' });
    }
    const password = auth.generateNumericPassword(4);
    const expiryDate = new Date(Date.now() + 30 * 86400000).toISOString().slice(0, 10);
    const user = sysUsers.createUser({ username, password, expiryDate, limit: 1 });
    res.status(201).json({ user });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.put('/api/users/:username', (req, res) => {
  try {
    const { password, expiryDate, limit } = req.body || {};
    const user = sysUsers.updateUser(req.params.username, {
      password: password || undefined,
      expiryDate: expiryDate !== undefined ? expiryDate : undefined,
      limit: limit !== undefined ? Number(limit) : undefined,
    });
    res.json({ user });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.delete('/api/users/:username', (req, res) => {
  try {
    sysUsers.deleteUser(req.params.username);
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/users/:username/block', (req, res) => {
  try {
    sysUsers.blockUser(req.params.username);
    res.json({ user: sysUsers.getUser(req.params.username) });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/users/:username/unblock', (req, res) => {
  try {
    sysUsers.unblockUser(req.params.username);
    res.json({ user: sysUsers.getUser(req.params.username) });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/api/generate-password', (req, res) => {
  const length = Math.min(Math.max(Number(req.query.length) || 20, 4), 100);
  res.json({ password: auth.generateRandomPassword(length) });
});

// --- Settings ------------------------------------------------------------------
app.post('/api/settings/password', (req, res) => {
  const { currentPassword, newPassword } = req.body || {};
  if (!auth.checkPassword(currentPassword || '')) {
    return res.status(401).json({ error: 'รหัสผ่านปัจจุบันไม่ถูกต้อง' });
  }
  if (!newPassword || newPassword.length < 8) {
    return res.status(400).json({ error: 'รหัสผ่านใหม่ต้องมีอย่างน้อย 8 ตัวอักษร' });
  }
  auth.setPassword(newPassword);
  res.json({ ok: true });
});

// Anything under /api that doesn't match a route above -> clean JSON 404
// instead of Express's default HTML page (the frontend always expects JSON).
app.use('/api', (req, res) => {
  res.status(404).json({ error: 'Not found' });
});

// Last-resort error handler: if any route above throws instead of catching
// its own error, this still returns JSON instead of crashing the request.
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error('Unhandled request error:', err);
  if (res.headersSent) return next(err);
  res.status(500).json({ error: 'Internal server error' });
});

// Log-only safety net for promise rejections (routes here don't have any
// that should realistically fire, but better to log than silently vanish).
// uncaughtException is handled separately below since it needs different
// treatment (see comment there).
process.on('unhandledRejection', (err) => {
  console.error('Unhandled promise rejection:', err);
});
process.on('uncaughtException', (err) => {
  // Per Node's own guidance, don't try to keep running after this — the
  // process may be in a corrupted state. Log it and exit so systemd's
  // Restart=always (2s) brings up a clean process. Sessions survive the
  // restart (see lib/auth.js), so this is no longer a "everyone gets logged
  // out" event.
  console.error('Uncaught exception, restarting:', err);
  process.exit(1);
});

app.listen(PORT, () => {
  console.log(`UDP Custom Panel listening on port ${PORT}`);
});
