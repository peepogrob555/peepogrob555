# UDP Custom (HTTP Custom) — Admin Panel

A self-hosted web dashboard for managing the SSH-tunnel accounts used by the
`udp-custom` service (the tool in the zip you shared). It manages real Linux
accounts using the **same conventions** as the bash menu that ships with
`udp-custom` (`module/udp`), so accounts you create from either tool stay in
sync:

- account: `useradd -M -s /bin/false -d /home/<user> <user>`
- expiry: `chage -E <date>`
- lock / unlock: `usermod -L` / `usermod -U`
- connection limit + display password: stored in the GECOS field as
  `<limit>,<password>`, exactly like the existing menu does.

## Requirements

- The VPS already running `udp-custom` (Ubuntu 20.04+, as in the zip's own README)
- Node.js 16+
- Root access (creating/locking system users requires it)

## Install

```bash
unzip udp-custom-panel.zip
cd udp-custom-panel
sudo ./install.sh
```

This installs dependencies, sets up a `udp-panel` systemd service on **port
2053**, and starts it.

To run it manually instead (e.g. for testing):

```bash
npm install
sudo PORT=2053 node server.js
```

## First login

On first start, a random 100-character admin password is generated and:

1. printed once in the console/log, and
2. saved to `data/INITIAL_ADMIN_PASSWORD.txt` (permissions `600`).

Copy it somewhere safe, then delete that file. You can set a new password
any time from **Settings → Change admin password** inside the panel.

Open `http://<your-server-ip>:2053` and log in with just that password —
there's no separate username, matching the "Admin" lock screen you asked for.

## What the panel does

- **Dashboard** — total users, how many are online right now, how many are
  blocked/expired, the server's public IP, and live service status for
  `udp-custom`, `udpgw`, and SSH.
- **Users** — searchable list of every tunnel account showing status
  (online/offline/blocked/expired), active connections vs. limit, expiry
  countdown, and a one-click **copy** chip with the exact
  `ip:1-65535@user:pass` string for pasting into HTTP Custom.
  - **Add user**: username, password (or a generate button), expiry date,
    max connections.
  - **Edit / Block / Unblock / Delete** per account.
  - **Details** view with the full connect string.
- **Logs** — shows `/etc/limit.log`, the same file the included
  `limiter.sh` writes to when it disconnects users over their limit or past
  expiry.
- **Settings** — change the admin password.

## Security notes (please read)

- This panel can create, delete, and lock real system accounts — treat the
  admin password like root access, because it effectively is.
- It's only served over plain HTTP. If this VPS is reachable from the
  internet on port 2053, put it behind a reverse proxy with TLS (e.g. Caddy
  or nginx + Let's Encrypt) rather than exposing it directly, or at minimum
  restrict port 2053 with a firewall rule to your own IP.
- Consider changing the default port and adding fail2ban / rate limiting on
  the login endpoint if the panel is internet-facing.
- The generated passwords are cryptographically random (Node's `crypto`
  module), not `Math.random()`.

## Project layout

```
server.js            Express app + routes
lib/auth.js           admin password hashing, sessions, random password generator
lib/sysUsers.js        Linux user management (useradd/chage/usermod/etc.)
lib/system.js         public IP lookup, systemd service status, log reader
public/               frontend (vanilla HTML/CSS/JS, no build step)
install.sh            installs deps + systemd service on port 2053
```

## Changelog — stability / mobile / copy fixes

- **Copy button actually copies now.** The old code called
  `navigator.clipboard.writeText()` directly. That API only exists in a
  *secure context* (HTTPS or `localhost`) — since this panel is served over
  plain HTTP, the call threw immediately in every modern mobile browser, so
  nothing was ever copied. The only thing that happened was the chip's CSS
  `:active` press animation, which fires on every tap regardless of whether
  the JS succeeded — that's the "press copy, nothing happens, just an
  animation" bug. Copy now tries the modern API, falls back to the legacy
  `execCommand('copy')` trick (works over plain HTTP), and if a browser/
  WebView blocks both, shows a small sheet with the full string pre-selected
  so you can long-press → Copy yourself.
- **Full `ip:1-65535@user:pass` is now fully visible**, not cut off with
  "…" — the chip used to truncate with `text-overflow: ellipsis`; it now
  wraps instead. The password was never actually masked in the data, just
  visually cut off.
- **Users list / dashboard no longer freezes the whole panel.** Listing N
  users used to run `chage -l`, `passwd -S`, and `ps -u <user>` **once per
  user** — each one a blocking subprocess spawn that froze the entire
  Node process (including login, for every other admin) until it returned.
  With dozens of accounts, that added up to real, noticeable lag/instability
  on every page load. Expiry and lock status are now read directly from
  `/etc/shadow` in one pass, and connection counts come from a single batched
  `ps` call — so listing users is O(1) subprocess spawns instead of O(3·N).
- **Live updates.** The dashboard/users view now polls every 7s (paused
  while the tab is hidden) instead of only fetching once on load, so
  "Online now" and per-user status actually stay current.
- **Sessions survive restarts.** Previously sessions lived only in memory,
  so any restart (crash, reboot, `systemctl restart udp-panel`) silently
  logged every admin out. Sessions are now persisted to `data/sessions.json`
  (same `0600` permissions as the admin password file) and reloaded on boot.
- Added a global error handler + `uncaughtException`/`unhandledRejection`
  handlers so one bad request can't take the whole panel down silently.
- `systemctl is-active` checks for the 4 services now run concurrently
  instead of one after another.
- Inputs are now ≥16px font-size, which stops iOS Safari from auto-zooming
  the page every time you tap a field.
- Bumped icon button touch targets from 34px to 38px for easier tapping.

### Why some accounts never show "Online" (please read)

This one is a real architectural limit, not something a panel-side fix can
fully solve — worth understanding rather than papering over:

Classic **SSH/Dropbear** tunnels work the way the original `ps -u <user>`
check assumed: the OS spawns a real process *owned by that Linux user* for
each connected session, so counting processes owned by a user is a reliable
way to know they're connected. That part is fixed above and works correctly.

**`udp-custom` doesn't work that way.** Looking at how it's installed
(`udp-custom.service` runs it once, as root, `Type=simple`) and configured
(`"auth": {"mode": "passwords"}`), it's a single long-running process that
authenticates against system passwords and handles every connected client
itself internally (Go's normal concurrency model — goroutines, not one OS
process per client). From the outside, there's simply no separate,
user-owned OS process to count for a udp-custom session — so no amount of
`ps`/`ss`/`netstat` parsing on the panel side can attribute a udp-custom
connection to a specific account. This is true for both terminal-created and
panel-created accounts equally; it's not related to how the account was
created.

If most of your real traffic is over UDP Custom (rather than plain SSH),
that's almost certainly why online status "never works" for those accounts
in particular.

**The one way to actually close this gap:** if your `udp-custom` binary logs
connection/auth events anywhere (stdout via `journalctl -u udp-custom`, or a
log file), we can parse that instead of relying on `ps`. Run this on the
server while a client is connected and send me a few sample lines, and I can
wire up real per-user detection for UDP Custom sessions too:

```bash
journalctl -u udp-custom -n 50 --no-pager
```

