#!/bin/bash

BLUE="\e[1;34m"
LBLUE="\e[1;94m"
WHITE="\e[1;97m"
GRAY="\e[1;90m"
RESET="\e[0m"

BASE_DIR="/etc/Shogun/system"

type_out() {
    local text="$1" delay="${2:-0.015}" i
    for (( i=0; i<${#text}; i++ )); do
        printf "%s" "${text:$i:1}"
        sleep "$delay"
    done
    echo ""
}

spinner() {
    local pid=$1 label="${2:-Working}"
    local frames=(⠋ ⠙ ⠹ ⠸ ⠼ ⠴ ⠦ ⠧ ⠇ ⠏)
    local i=0
    tput civis 2>/dev/null
    while kill -0 "$pid" 2>/dev/null; do
        i=$(( (i + 1) % ${#frames[@]} ))
        printf "\r${LBLUE}%s${RESET} ${WHITE}%s...${RESET}   " "${frames[$i]}" "$label"
        sleep 0.08
    done
    wait "$pid" 2>/dev/null
    local rc=$?
    if [[ $rc -eq 0 ]]; then
        printf "\r${LBLUE}✓${RESET} ${WHITE}%s... done${RESET}        \n" "$label"
    else
        printf "\r${GRAY}✗${RESET} ${WHITE}%s... failed${RESET}      \n" "$label"
    fi
    tput cnorm 2>/dev/null
    return $rc
}

progress_bar() {
    local label="$1" width=30 steps=20 s filled empty pct bar_f bar_e
    echo -e "${WHITE}${label}${RESET}"
    for (( s=1; s<=steps; s++ )); do
        filled=$(( s * width / steps ))
        empty=$(( width - filled ))
        bar_f=$(printf '█%.0s' $(seq 1 "$filled" 2>/dev/null))
        bar_e=$(printf '─%.0s' $(seq 1 "$empty" 2>/dev/null))
        pct=$(( s * 100 / steps ))
        printf "\r${BLUE}[${LBLUE}%s${GRAY}%s${BLUE}]${WHITE} %3d%%${RESET}" "$bar_f" "$bar_e" "$pct"
        sleep 0.04
    done
    echo ""
}

usage_bar() {
    local pct=${1:-0} width=24 filled empty bar_f bar_e
    [[ $pct -gt 100 ]] && pct=100
    filled=$(( pct * width / 100 ))
    empty=$(( width - filled ))
    bar_f=$(printf '█%.0s' $(seq 1 "$filled" 2>/dev/null))
    bar_e=$(printf '░%.0s' $(seq 1 "$empty" 2>/dev/null))
    printf "${BLUE}[${LBLUE}%s${GRAY}%s${BLUE}]${WHITE} %3d%%${RESET}" "$bar_f" "$bar_e" "$pct"
}

status_dot() {
    if systemctl is-active --quiet "$1" 2>/dev/null; then
        printf "${LBLUE}●${RESET} ${WHITE}running${RESET}"
    else
        printf "${GRAY}●${RESET} ${GRAY}stopped${RESET}"
    fi
}

logo() {
    if command -v figlet >/dev/null 2>&1; then
        figlet -f big -w 100 "SHOGUN" 2>/dev/null | awk -v b="$BLUE" -v w="$WHITE" -v r="$RESET" \
            'NF{ if (NR%2==1) printf "%s%s%s\n",b,$0,r; else printf "%s%s%s\n",w,$0,r }'
    else
        echo -e "${BLUE}   ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄${RESET}"
        echo -e "${WHITE}          S H O G U N   P A N E L${RESET}"
        echo -e "${BLUE}   ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄${RESET}"
    fi
}

banner() {
    clear
    logo
    echo -e "${GRAY}   ──────────────────────────────────────────────────${RESET}"
}

