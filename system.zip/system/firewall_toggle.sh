#!/bin/bash

source "$(dirname "$0")/colors.sh"

STATE_FILE="/etc/Shogun/firewall_locked"

banner

if [[ -f "$STATE_FILE" ]]; then
    echo -e "${WHITE}Firewall rules are currently ${LBLUE}ENABLED${WHITE} (torrent traffic blocked).${RESET}"
    read -rp "Disable firewall rules? (y/n) " yn
    if [[ "$yn" =~ [Yy] ]]; then
        (
            iptables -F
            iptables -X
            iptables -t nat -F
            iptables -t nat -X
            iptables -t mangle -F
            iptables -t mangle -X
            iptables -P INPUT ACCEPT
            iptables -P OUTPUT ACCEPT
            iptables -P FORWARD ACCEPT
            rm -f "$STATE_FILE"
            sleep 0.4
        ) & pid=$!
        spinner "$pid" "Removing firewall rules"
    fi
else
    echo -e "${WHITE}Firewall rules are currently ${GRAY}DISABLED${WHITE}.${RESET}"
    read -rp "Enable firewall rules to block torrent traffic? (y/n) " yn
    if [[ "$yn" =~ [Yy] ]]; then
        (
            iptables -A FORWARD -m string --algo bm --string "BitTorrent" -j DROP
            iptables -A FORWARD -m string --algo bm --string "peer_id=" -j DROP
            iptables -A FORWARD -m string --algo bm --string "announce.php?" -j DROP
            iptables -A FORWARD -m string --algo bm --string "info_hash" -j DROP
            mkdir -p /etc/Shogun
            touch "$STATE_FILE"
            sleep 0.4
        ) & pid=$!
        spinner "$pid" "Applying firewall rules"
    fi
fi

echo -e "\n${GRAY}Press Enter to return to the menu${RESET}"; read -r
exec "$BASE_DIR/menu"

