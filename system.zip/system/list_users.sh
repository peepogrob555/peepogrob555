#!/bin/bash

source "$(dirname "$0")/colors.sh"

banner
progress_bar "Scanning accounts"
echo ""

printf "${WHITE}%-16s %-10s %-14s${RESET}\n" "USERNAME" "LIMIT" "EXPIRES"
echo -e "${BLUE}────────────────────────────────────────────${RESET}"

total=0
expired=0
soon=0

for username in $(awk -F: '$3>=1000 && $1!="nobody" {print $1}' /etc/passwd); do
    total=$((total + 1))

    limit_file="/etc/security/limits.d/${username}.conf"
    if [[ -f "$limit_file" ]]; then
        limit=$(awk '{print $NF}' "$limit_file")
    else
        limit="-"
    fi

    exp_raw=$(chage -l "$username" 2>/dev/null | grep "Account expires" | awk -F: '{print $2}' | xargs)
    color="$WHITE"
    if [[ -z "$exp_raw" || "$exp_raw" == "never" ]]; then
        exp_display="Never"
    else
        exp_epoch=$(date -d "$exp_raw" +%s 2>/dev/null)
        now_epoch=$(date +%s)
        if [[ -n "$exp_epoch" && "$exp_epoch" -lt "$now_epoch" ]]; then
            exp_display="Expired"
            color="$GRAY"
            expired=$((expired + 1))
        else
            days_left=$(( (exp_epoch - now_epoch) / 86400 ))
            exp_display="$exp_raw (${days_left}d)"
            if [[ "$days_left" -le 3 ]]; then
                color="$LBLUE"
                soon=$((soon + 1))
            fi
        fi
    fi

    printf "${color}%-16s %-10s %-14s${RESET}\n" "$username" "$limit" "$exp_display"
done

echo -e "${BLUE}────────────────────────────────────────────${RESET}"
echo -e "${WHITE}Total: ${LBLUE}${total}${WHITE}   Expired: ${GRAY}${expired}${WHITE}   Expiring soon: ${LBLUE}${soon}${RESET}"

echo -e "\n${GRAY}Press Enter to return to the menu${RESET}"; read -r
exec "$BASE_DIR/menu"

