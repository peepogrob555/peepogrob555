#!/bin/bash

source "$(dirname "$0")/colors.sh"

banner
progress_bar "Reading system status"
echo ""

hostname_v=$(hostname 2>/dev/null)
os_v=$( { grep -m1 PRETTY_NAME /etc/os-release 2>/dev/null | cut -d'"' -f2; } )
kernel_v=$(uname -r)
uptime_v=$(uptime -p 2>/dev/null | sed 's/^up //')
load_v=$(cut -d' ' -f1-3 /proc/loadavg 2>/dev/null)
pub_ip=$(wget -qO- https://ipecho.net/plain 2>/dev/null)

mem_total=$(awk '/MemTotal/{print $2}' /proc/meminfo)
mem_avail=$(awk '/MemAvailable/{print $2}' /proc/meminfo)
if [[ -n "$mem_total" && -n "$mem_avail" && "$mem_total" -gt 0 ]]; then
    mem_used_pct=$(( (mem_total - mem_avail) * 100 / mem_total ))
else
    mem_used_pct=0
fi

disk_pct=$(df -P / 2>/dev/null | awk 'NR==2{gsub("%","",$5); print $5}')
[[ -z "$disk_pct" ]] && disk_pct=0

total_users=$(awk -F: '$3>=1000 && $1!="nobody"' /etc/passwd | wc -l)

echo -e "${WHITE}Hostname     : ${LBLUE}${hostname_v}${RESET}"
echo -e "${WHITE}OS           : ${LBLUE}${os_v:-unknown}${RESET}"
echo -e "${WHITE}Kernel       : ${LBLUE}${kernel_v}${RESET}"
echo -e "${WHITE}IP Address   : ${LBLUE}${pub_ip}${RESET}"
echo -e "${WHITE}Uptime       : ${LBLUE}${uptime_v:-unknown}${RESET}"
echo -e "${WHITE}Load Avg     : ${LBLUE}${load_v}${RESET}"
echo ""
printf "${WHITE}Memory       : ${RESET}"; usage_bar "$mem_used_pct"; echo ""
printf "${WHITE}Disk (/)     : ${RESET}"; usage_bar "$disk_pct"; echo ""
echo ""
echo -e "${WHITE}udp-custom   : $(status_dot udp-custom)${RESET}"
echo -e "${WHITE}Panel users  : ${LBLUE}${total_users}${RESET}"

echo -e "\n${GRAY}Press Enter to return to the menu${RESET}"; read -r
exec "$BASE_DIR/menu"

