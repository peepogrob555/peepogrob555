#!/bin/bash

source "$(dirname "$0")/colors.sh"

banner
read -rp "Remove the SHOGUN panel and udp-custom service? (y/n) " yn

if [[ "$yn" =~ [Yy] ]]; then
    (
        systemctl stop udp-custom 2>/dev/null
        systemctl disable udp-custom 2>/dev/null
        rm -rf /root/udp
        rm -rf /etc/Shogun
        rm -f /usr/local/bin/menu
        systemctl daemon-reload
        sed -i '/\/usr\/sbin\/nologin/d' /etc/shells 2>/dev/null
        sleep 0.5
    ) & pid=$!
    spinner "$pid" "Removing SHOGUN panel"
    echo -e "\n${GRAY}Press Enter to exit${RESET}"; read -r
    clear
    exit 0
else
    echo -e "${GRAY}Cancelled.${RESET}"
    echo -e "\n${GRAY}Press Enter to return to the menu${RESET}"; read -r
    exec "$BASE_DIR/menu"
fi

