#!/bin/bash

source "$(dirname "$0")/colors.sh"

s_ip=$(wget -qO- https://ipecho.net/plain 2>/dev/null)

banner
echo -ne "${WHITE}Username: ${RESET}"; read -r username

while true; do
    read -rp "Generate a random password? (y/n) " yn
    case "$yn" in
        [Yy]*) password=$(< /dev/urandom tr -dc 'A-Za-z0-9' | head -c12); break ;;
        [Nn]*) echo -ne "${WHITE}Enter password: ${RESET}"; read -r password; break ;;
        *) echo -e "${GRAY}Please answer y or n.${RESET}" ;;
    esac
done

echo -ne "${WHITE}Days until expiration: ${RESET}"; read -r days
exp_date=$(date +%F -d "$days days")

echo -ne "${WHITE}Max simultaneous logins: ${RESET}"; read -r maxlogins

echo ""
(
    echo "$username hard maxlogins ${maxlogins}" > "/etc/security/limits.d/${username}.conf"
    if useradd -e "$exp_date" -M -N -s /usr/sbin/nologin "$username" 2>/dev/null \
        && echo "${username}:${password}" | chpasswd; then
        sleep 0.4; exit 0
    else
        sleep 0.4; exit 1
    fi
) & pid=$!
spinner "$pid" "Creating account"
rc=$?

if [[ $rc -eq 0 ]]; then
    echo ""
    echo -e "${BLUE}   ┌──────────────────────────────────────────────┐${RESET}"
    printf "${WHITE}   │ IP Address   : ${LBLUE}%-30s${WHITE} ${BLUE}│${RESET}\n" "$s_ip"
    printf "${WHITE}   │ Username     : ${LBLUE}%-30s${WHITE} ${BLUE}│${RESET}\n" "$username"
    printf "${WHITE}   │ Password     : ${LBLUE}%-30s${WHITE} ${BLUE}│${RESET}\n" "$password"
    printf "${WHITE}   │ Expire Date  : ${LBLUE}%-30s${WHITE} ${BLUE}│${RESET}\n" "$exp_date"
    printf "${WHITE}   │ Max Logins   : ${LBLUE}%-30s${WHITE} ${BLUE}│${RESET}\n" "$maxlogins"
    printf "${WHITE}   │ UDP Ports    : ${LBLUE}%-30s${WHITE} ${BLUE}│${RESET}\n" "1-65535"
    echo -e "${BLUE}   └──────────────────────────────────────────────┘${RESET}"
else
    echo -e "${GRAY}Failed to create user ${username}. It may already exist.${RESET}"
fi

echo -e "\n${GRAY}Press Enter to return to the menu${RESET}"; read -r
exec "$BASE_DIR/menu"

