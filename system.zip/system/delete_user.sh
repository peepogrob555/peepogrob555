#!/bin/bash

source "$(dirname "$0")/colors.sh"

banner
echo -e "${WHITE}Current users:${RESET}"
echo -e "${BLUE}   ──────────────────────${RESET}"
awk -F: '$3>=1000 && $1!="nobody" {print "  - "$1}' /etc/passwd
echo -e "${BLUE}   ──────────────────────${RESET}"
echo ""

echo -ne "${WHITE}Username to delete: ${RESET}"; read -r username

read -rp "Delete user ${username}? (y/n) " yn
case "$yn" in
    [Yy]*)
        (
            if userdel "$username" 2>/dev/null; then
                rm -f "/etc/security/limits.d/${username}.conf"
                sleep 0.4
                exit 0
            else
                sleep 0.4
                exit 1
            fi
        ) & pid=$!
        spinner "$pid" "Deleting ${username}"
        if [[ $? -ne 0 ]]; then
            echo -e "${GRAY}Failed to delete ${username} (user may not exist).${RESET}"
        fi
        ;;
    *)
        echo -e "${GRAY}Cancelled.${RESET}"
        ;;
esac

echo -e "\n${GRAY}Press Enter to return to the menu${RESET}"; read -r
exec "$BASE_DIR/menu"

