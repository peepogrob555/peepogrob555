#!/bin/bash

source "$(dirname "$0")/colors.sh"

banner
echo -ne "${WHITE}Username to edit: ${RESET}"; read -r username

if ! id "$username" &>/dev/null; then
    echo -e "${GRAY}User ${username} does not exist.${RESET}"
    echo -e "\n${GRAY}Press Enter to return to the menu${RESET}"; read -r
    exec "$BASE_DIR/menu"
fi

while true; do
    read -rp "Generate a new random password? (y/n) " yn
    case "$yn" in
        [Yy]*) password=$(< /dev/urandom tr -dc 'A-Za-z0-9' | head -c12); break ;;
        [Nn]*) echo -ne "${WHITE}New password: ${RESET}"; read -r password; break ;;
        *) echo -e "${GRAY}Please answer y or n.${RESET}" ;;
    esac
done

echo -ne "${WHITE}New days until expiration: ${RESET}"; read -r days
exp_date=$(date +%F -d "$days days")

echo ""
(
    if chage -E "$exp_date" "$username" && echo "${username}:${password}" | chpasswd; then
        sleep 0.4; exit 0
    else
        sleep 0.4; exit 1
    fi
) & pid=$!
spinner "$pid" "Updating account"
rc=$?

if [[ $rc -eq 0 ]]; then
    echo ""
    echo -e "${BLUE}   ┌──────────────────────────────────────────────┐${RESET}"
    printf "${WHITE}   │ Username     : ${LBLUE}%-30s${WHITE} ${BLUE}│${RESET}\n" "$username"
    printf "${WHITE}   │ Password     : ${LBLUE}%-30s${WHITE} ${BLUE}│${RESET}\n" "$password"
    printf "${WHITE}   │ Expire Date  : ${LBLUE}%-30s${WHITE} ${BLUE}│${RESET}\n" "$exp_date"
    echo -e "${BLUE}   └──────────────────────────────────────────────┘${RESET}"
else
    echo -e "${GRAY}Failed to update ${username}.${RESET}"
fi

echo -e "\n${GRAY}Press Enter to return to the menu${RESET}"; read -r
exec "$BASE_DIR/menu"

