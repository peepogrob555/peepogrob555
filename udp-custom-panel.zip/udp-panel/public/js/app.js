const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

const ICONS = {
  signal: 'M50 79l9.5-9.5a13.4 13.4 0 00-19 0L50 79zm-22-22l6.8-6.8a22 22 0 0130.4 0L72 57a31 31 0 00-44 0zm-15-15l6.8-6.8a43 43 0 0160.4 0L87 42a52 52 0 00-74 0z',
  eye: 'M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5C21.27 7.61 17 4.5 12 4.5zm0 12.5a5 5 0 110-10 5 5 0 010 10zm0-8a3 3 0 100 6 3 3 0 000-6z',
  edit: 'M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04a1 1 0 000-1.41l-2.34-2.34a1 1 0 00-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z',
  lock: 'M12 17a2 2 0 002-2 2 2 0 00-2-2 2 2 0 00-2 2 2 2 0 002 2zm6-9h-1V6a5 5 0 00-10 0v2H6a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V10a2 2 0 00-2-2zM9 6a3 3 0 016 0v2H9V6z',
  unlock: 'M12 17a2 2 0 002-2 2 2 0 00-2-2 2 2 0 00-2 2 2 2 0 002 2zm6-9h-9V6a3 3 0 016 0h2a5 5 0 00-10 0v2H6a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V10a2 2 0 00-2-2z',
  trash: 'M7 7h10l-.9 12.1a2 2 0 01-2 1.9H9.9a2 2 0 01-2-1.9L7 7zm3-3h4l1 2H9l1-2zM5 7h14',
  plus: 'M12 5v14M5 12h14',
  close: 'M6 6l12 12M18 6L6 18',
  check: 'M5 13l4 4L19 7',
  copy: 'M9 9h9v10H9zM6 6h9v1.6H8.4A1.8 1.8 0 006.6 9.4V17H5V6z',
  power: 'M13 3h-2v10h2V3zm4.83 2.17l-1.42 1.42A6.92 6.92 0 0119 12a7 7 0 11-11.66-5.24L5.92 5.34A9 9 0 1017.83 5.17z',
  users: 'M12 12a5 5 0 100-10 5 5 0 000 10zm0 2c-4.4 0-9 2.2-9 5.5V22h18v-2.5c0-3.3-4.6-5.5-9-5.5z',
};

function svg(name, cls) {
  return `<svg viewBox="0 0 24 24" class="${cls || ''}"><path d="${ICONS[name]}"/></svg>`;
}

// ---------------------------------------------------------------------------
// Starfield — ambient background with drifting stars and shooting stars
// ---------------------------------------------------------------------------
(function starfield() {
  const canvas = $('#stars');
  const ctx = canvas.getContext('2d');
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let w, h, dpr, stars = [], shooters = [], raf = null, lastT = 0, nextShot = 0;

  function resize() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    w = window.innerWidth; h = window.innerHeight;
    canvas.width = w * dpr; canvas.height = h * dpr;
    canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const count = Math.min(90, Math.round((w * h) / 9000));
    stars = Array.from({ length: count }, () => ({
      x: Math.random() * w,
      y: Math.random() * h,
      r: Math.random() * 1.3 + 0.3,
      phase: Math.random() * Math.PI * 2,
      speed: 0.6 + Math.random() * 1.2,
    }));
  }

  function spawnShooter() {
    const startX = Math.random() * w * 0.7;
    shooters.push({
      x: startX, y: -20,
      vx: 260 + Math.random() * 120,
      vy: 160 + Math.random() * 80,
      life: 0, maxLife: 900 + Math.random() * 300,
      len: 90 + Math.random() * 60,
    });
  }

  function draw(t) {
    const dt = Math.min(t - lastT, 50);
    lastT = t;

    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = '#fff';
    for (const s of stars) {
      s.phase += dt * 0.001 * s.speed;
      const tw = 0.35 + Math.sin(s.phase) * 0.35 + 0.3;
      ctx.globalAlpha = Math.max(0.15, tw);
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;

    if (t > nextShot) {
      spawnShooter();
      nextShot = t + 3500 + Math.random() * 5500;
    }

    shooters = shooters.filter((sh) => sh.life < sh.maxLife);
    for (const sh of shooters) {
      sh.life += dt;
      sh.x += sh.vx * (dt / 1000);
      sh.y += sh.vy * (dt / 1000);
      const p = sh.life / sh.maxLife;
      const fade = p < 0.15 ? p / 0.15 : 1 - (p - 0.15) / 0.85;
      const ang = Math.atan2(sh.vy, sh.vx);
      const tx = sh.x - Math.cos(ang) * sh.len;
      const ty = sh.y - Math.sin(ang) * sh.len;
      const grad = ctx.createLinearGradient(sh.x, sh.y, tx, ty);
      grad.addColorStop(0, `rgba(255,255,255,${0.9 * fade})`);
      grad.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.strokeStyle = grad;
      ctx.lineWidth = 1.6;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(sh.x, sh.y);
      ctx.lineTo(tx, ty);
      ctx.stroke();
    }

    raf = requestAnimationFrame(draw);
  }

  function start() {
    if (raf) return;
    lastT = performance.now();
    nextShot = lastT + 1500;
    raf = requestAnimationFrame(draw);
  }
  function stop() {
    if (raf) cancelAnimationFrame(raf);
    raf = null;
  }

  resize();
  window.addEventListener('resize', resize, { passive: true });
  document.addEventListener('visibilitychange', () => (document.hidden ? stop() : start()));

  if (reduced) {
    draw(0);
  } else {
    start();
  }
})();

// ---------------------------------------------------------------------------
// Ripple + haptics
// ---------------------------------------------------------------------------
document.addEventListener('pointerdown', (e) => {
  const btn = e.target.closest('button');
  if (!btn || btn.disabled) return;
  const rect = btn.getBoundingClientRect();
  const size = Math.max(rect.width, rect.height) * 1.4;
  const ripple = document.createElement('span');
  ripple.className = 'ripple';
  ripple.style.width = ripple.style.height = size + 'px';
  ripple.style.left = e.clientX - rect.left - size / 2 + 'px';
  ripple.style.top = e.clientY - rect.top - size / 2 + 'px';
  btn.appendChild(ripple);
  setTimeout(() => ripple.remove(), 600);
});

function haptic(ms = 8) {
  if (navigator.vibrate) navigator.vibrate(ms);
}

// ---------------------------------------------------------------------------
// Toast
// ---------------------------------------------------------------------------
function toast(msg, isError = false) {
  const el = $('#toast');
  el.innerHTML = `<div class="toast-bar"></div>${svg(isError ? 'close' : 'check')}<span>${msg}</span>`;
  el.classList.toggle('err', isError);
  void el.offsetWidth;
  el.classList.add('show');
  haptic(isError ? [10, 30, 10] : 8);
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.remove('show'), 2600);
}

// ---------------------------------------------------------------------------
// Animated counters
// ---------------------------------------------------------------------------
function animateValue(el, to) {
  el.classList.remove('skeleton');
  const from = 0;
  const dur = 700;
  const start = performance.now();
  function step(t) {
    const p = Math.min((t - start) / dur, 1);
    const eased = 1 - Math.pow(1 - p, 3);
    el.textContent = Math.round(from + (to - from) * eased);
    if (p < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

// ---------------------------------------------------------------------------
// Bottom sheets
// ---------------------------------------------------------------------------
function openSheet(id) {
  const el = $('#' + id);
  el.hidden = false;
  void el.offsetWidth;
  el.classList.add('open');
  haptic(6);
}
function closeSheet(id) {
  const el = $('#' + id);
  el.classList.remove('open');
  setTimeout(() => (el.hidden = true), 450);
}
$$('[data-drag]').forEach((handle) => {
  const id = handle.dataset.drag;
  const sheetEl = $('#' + id).querySelector('.sheet');
  let startY = 0, dy = 0, dragging = false;
  handle.addEventListener('touchstart', (e) => {
    startY = e.touches[0].clientY;
    dragging = true;
    sheetEl.classList.add('dragging');
  }, { passive: true });
  handle.addEventListener('touchmove', (e) => {
    if (!dragging) return;
    dy = Math.max(0, e.touches[0].clientY - startY);
    sheetEl.style.transform = `translateY(${dy}px)`;
  }, { passive: true });
  handle.addEventListener('touchend', () => {
    dragging = false;
    sheetEl.classList.remove('dragging');
    sheetEl.style.transform = '';
    if (dy > 110) closeSheet(id);
    dy = 0;
  });
});

// ---------------------------------------------------------------------------
// API helper
// ---------------------------------------------------------------------------
async function api(path, options = {}) {
  const res = await fetch('/api' + path, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  let body = null;
  try { body = await res.json(); } catch {}
  if (!res.ok) throw new Error((body && body.error) || `Request failed (${res.status})`);
  return body;
}

let serverIp = '';
let usersCache = [];

// ---------------------------------------------------------------------------
// Auth / boot
// ---------------------------------------------------------------------------
async function boot() {
  $('#loginBrandMark').innerHTML = svg('signal');
  $('#topbarBrandMark').innerHTML = svg('signal');
  $('#logoutBtn').innerHTML = svg('power');
  $('#openAddUser').innerHTML = svg('plus');
  $('#closeModal').innerHTML = svg('close');
  $('#closeDetailModal').innerHTML = svg('close');

  try {
    const { authenticated } = await api('/session');
    if (authenticated) return showApp();
  } catch {}
  showLogin();
}

function showLogin() {
  $('#loginView').hidden = false;
  $('#appView').hidden = true;
}

async function showApp() {
  $('#loginView').hidden = true;
  $('#appView').hidden = false;
  initNavIndicator();
  await refreshServerInfo();
  await refreshUsers();
  renderDashboard();
}

$('#loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = $('#loginBtn');
  const password = $('#adminPassword').value;
  const errEl = $('#loginError');
  errEl.hidden = true;
  btn.disabled = true;
  const original = btn.textContent;
  btn.innerHTML = '<span class="spinner"></span>Unlocking…';
  try {
    await api('/login', { method: 'POST', body: JSON.stringify({ password }) });
    $('#adminPassword').value = '';
    await showApp();
  } catch (err) {
    errEl.textContent = err.message;
    errEl.hidden = false;
    haptic([10, 30, 10]);
  } finally {
    btn.disabled = false;
    btn.textContent = original;
  }
});

$('#logoutBtn').addEventListener('click', async () => {
  await api('/logout', { method: 'POST' });
  showLogin();
});

// ---------------------------------------------------------------------------
// Navigation
// ---------------------------------------------------------------------------
const VIEW_TITLES = { dashboard: 'Dashboard', users: 'Users', logs: 'Logs', settings: 'Settings' };

function initNavIndicator() {
  const active = $('.nav-tab.active') || $('.nav-tab');
  moveIndicator(active);
}
function moveIndicator(btn) {
  const ind = $('#navIndicator');
  const nav = $('.bottom-nav');
  const navRect = nav.getBoundingClientRect();
  const rect = btn.getBoundingClientRect();
  ind.style.width = rect.width + 'px';
  ind.style.transform = `translateX(${rect.left - navRect.left}px)`;
}
window.addEventListener('resize', () => {
  const active = $('.nav-tab.active');
  if (active && !$('#appView').hidden) moveIndicator(active);
}, { passive: true });

$$('.nav-tab').forEach((btn) => {
  btn.addEventListener('click', () => switchView(btn.dataset.view, btn));
});
$$('[data-goto]').forEach((btn) =>
  btn.addEventListener('click', () => switchView(btn.dataset.goto, $(`.nav-tab[data-view="${btn.dataset.goto}"]`)))
);

function switchView(name, btn) {
  $$('.nav-tab').forEach((b) => b.classList.toggle('active', b.dataset.view === name));
  if (btn) moveIndicator(btn);
  $$('.view').forEach((v) => v.classList.remove('active'));
  const target = $(`#view-${name}`);
  void target.offsetWidth;
  target.classList.add('active');
  $('#topbarTitle').textContent = VIEW_TITLES[name] || '';
  if (name === 'logs') loadLogs();
  if (name === 'users') renderUsersList();
  haptic(6);
}

// ---------------------------------------------------------------------------
// Server info / dashboard
// ---------------------------------------------------------------------------
async function refreshServerInfo() {
  try {
    const info = await api('/server-info');
    serverIp = info.ip || '—';
    const el = $('#statIp');
    el.classList.remove('skeleton');
    el.textContent = serverIp;
    renderServices(info.services);
  } catch {
    const el = $('#statIp');
    el.classList.remove('skeleton');
    el.textContent = '—';
  }
}

function renderServices(services = []) {
  $('#serviceList').innerHTML = services
    .map((s) => `<div class="service-item"><span class="dot ${s.active ? 'on' : ''}"></span>${s.label}</div>`)
    .join('');
}

async function refreshUsers() {
  const { users } = await api('/users');
  usersCache = users;
}

function renderDashboard() {
  const total = usersCache.length;
  const online = usersCache.filter((u) => u.status === 'online').length;
  const blocked = usersCache.filter((u) => u.status === 'blocked' || u.status === 'expired').length;
  animateValue($('#statTotal'), total);
  animateValue($('#statOnline'), online);
  animateValue($('#statBlocked'), blocked);

  const recent = usersCache.slice(0, 5);
  $('#recentUsers').innerHTML = usersListHtml(recent, { compact: true });
  bindCardActions($('#recentUsers'));
}

// ---------------------------------------------------------------------------
// Users view
// ---------------------------------------------------------------------------
$('#userSearch').addEventListener('input', () => renderUsersList(false));

async function renderUsersList(refetch = true) {
  if (refetch) await refreshUsers();
  const q = $('#userSearch').value.trim().toLowerCase();
  const filtered = q ? usersCache.filter((u) => u.username.toLowerCase().includes(q)) : usersCache;
  $('#usersList').innerHTML = usersListHtml(filtered, { compact: false });
  bindCardActions($('#usersList'));
}

function statusBadge(u) {
  if (u.status === 'blocked') return '<span class="badge badge-blocked">Blocked</span>';
  if (u.status === 'expired') return '<span class="badge badge-expired">Expired</span>';
  if (u.status === 'online') return '<span class="badge badge-online">Online</span>';
  return '<span class="badge badge-offline">Offline</span>';
}

function connectString(u) {
  const ip = serverIp || 'YOUR.SERVER.IP';
  return `${ip}:1-65535@${u.username}:${u.password || ''}`;
}

function usersListHtml(users, { compact }) {
  if (!users.length) {
    return `<div class="empty-state">${svg('users')}<div>No accounts yet.${compact ? '' : ' Tap the + button to create one.'}</div></div>`;
  }
  return users
    .map((u, i) => {
      const expiry = u.expiryDate ? `${u.expiryDate} · ${u.daysLeft >= 0 ? u.daysLeft + 'd left' : 'expired'}` : 'Never expires';
      const connCol = `${u.connected}${u.limit ? ' / ' + u.limit : ''} conn.`;
      const initials = u.username.slice(0, 2).toUpperCase();
      const actions = compact
        ? ''
        : `<div class="user-card-actions">
            <button class="icon-btn" data-action="view" data-user="${u.username}" aria-label="Details">${svg('eye')}</button>
            <button class="icon-btn" data-action="edit" data-user="${u.username}" aria-label="Edit">${svg('edit')}</button>
            ${
              u.status === 'blocked'
                ? `<button class="icon-btn on-green" data-action="unblock" data-user="${u.username}" aria-label="Unblock">${svg('unlock')}</button>`
                : `<button class="icon-btn on-accent" data-action="block" data-user="${u.username}" aria-label="Block">${svg('lock')}</button>`
            }
            <button class="icon-btn on-danger" data-action="delete" data-user="${u.username}" aria-label="Delete">${svg('trash')}</button>
          </div>`;
      return `<div class="user-card" style="animation-delay:${Math.min(i * 40, 400)}ms">
        <div class="user-card-top">
          <div class="user-card-id">
            <div class="user-avatar">${initials}</div>
            <span class="user-card-name">${u.username}</span>
          </div>
          ${statusBadge(u)}
        </div>
        <div class="user-card-meta"><span>${connCol}</span><span>${expiry}</span></div>
        <span class="copy-chip" data-action="copy" data-copy="${connectString(u)}">
          <span class="txt">${connectString(u)}</span>${svg('copy')}
        </span>
        ${actions}
      </div>`;
    })
    .join('');
}

function bindCardActions(root) {
  $$('[data-action="copy"]', root).forEach((el) => el.addEventListener('click', () => copyToClipboard(el)));
  $$('[data-action="view"]', root).forEach((el) => el.addEventListener('click', () => openDetail(el.dataset.user)));
  $$('[data-action="edit"]', root).forEach((el) => el.addEventListener('click', () => openUserModal(el.dataset.user)));
  $$('[data-action="block"]', root).forEach((el) => el.addEventListener('click', () => toggleBlock(el.dataset.user, true)));
  $$('[data-action="unblock"]', root).forEach((el) => el.addEventListener('click', () => toggleBlock(el.dataset.user, false)));
  $$('[data-action="delete"]', root).forEach((el) => el.addEventListener('click', () => deleteUser(el.dataset.user)));
}

function copyToClipboard(el) {
  const text = el.dataset.copy;
  navigator.clipboard
    .writeText(text)
    .then(() => {
      el.classList.add('copied');
      haptic(10);
      setTimeout(() => el.classList.remove('copied'), 1400);
    })
    .catch(() => toast('Could not copy — select and copy manually', true));
}

async function toggleBlock(username, block) {
  try {
    await api(`/users/${encodeURIComponent(username)}/${block ? 'block' : 'unblock'}`, { method: 'POST' });
    toast(block ? `${username} blocked` : `${username} unblocked`);
    await renderUsersList();
    renderDashboard();
  } catch (err) {
    toast(err.message, true);
  }
}

async function deleteUser(username) {
  if (!confirm(`Delete account "${username}"? This cannot be undone.`)) return;
  try {
    await api(`/users/${encodeURIComponent(username)}`, { method: 'DELETE' });
    toast(`${username} deleted`);
    await renderUsersList();
    renderDashboard();
  } catch (err) {
    toast(err.message, true);
  }
}

// ---------------------------------------------------------------------------
// Detail sheet
// ---------------------------------------------------------------------------
function openDetail(username) {
  const u = usersCache.find((x) => x.username === username);
  if (!u) return;
  const expiry = u.expiryDate ? `${u.expiryDate} (${u.daysLeft >= 0 ? u.daysLeft + ' days left' : 'expired'})` : 'Never';
  $('#detailBody').innerHTML = `
    <div class="row"><span>Username</span><span>${u.username}</span></div>
    <div class="row"><span>Password</span><span>${u.password || '—'}</span></div>
    <div class="row"><span>Status</span><span>${statusBadge(u)}</span></div>
    <div class="row"><span>Connections</span><span>${u.connected} / ${u.limit || '∞'}</span></div>
    <div class="row"><span>Expires</span><span>${expiry}</span></div>
    <span class="copy-chip" data-action="copy" data-copy="${connectString(u)}" style="margin-top:12px">
      <span class="txt">${connectString(u)}</span>${svg('copy')}
    </span>
  `;
  bindCardActions($('#detailBody'));
  openSheet('detailSheet');
}
$('#closeDetailModal').addEventListener('click', () => closeSheet('detailSheet'));
$('#detailSheet').addEventListener('click', (e) => {
  if (e.target.id === 'detailSheet') closeSheet('detailSheet');
});

// ---------------------------------------------------------------------------
// Add / edit user sheet
// ---------------------------------------------------------------------------
$('#openAddUser').addEventListener('click', () => openUserModal(null));
$('#closeModal').addEventListener('click', closeUserModal);
$('#cancelUserBtn').addEventListener('click', closeUserModal);
$('#userSheet').addEventListener('click', (e) => {
  if (e.target.id === 'userSheet') closeUserModal();
});

function openUserModal(username) {
  const editing = !!username;
  $('#modalTitle').textContent = editing ? `Edit ${username}` : 'Add user';
  $('#editUsername').value = username || '';
  $('#fUsername').value = username || '';
  $('#fUsername').disabled = editing;
  $('#modalError').hidden = true;

  if (editing) {
    const u = usersCache.find((x) => x.username === username);
    $('#fPassword').value = u.password || '';
    $('#fExpiry').value = u.expiryDate || '';
    $('#fLimit').value = u.limit || 1;
  } else {
    $('#fPassword').value = '';
    $('#fExpiry').value = '';
    $('#fLimit').value = 1;
  }
  openSheet('userSheet');
}

function closeUserModal() {
  closeSheet('userSheet');
  $('#userForm').reset();
  $('#fUsername').disabled = false;
}

$('#fGenPass').addEventListener('click', async () => {
  const { password } = await api('/generate-password?length=20');
  $('#fPassword').value = password;
  haptic(8);
});

$('#userForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const editing = $('#editUsername').value;
  const payload = {
    username: $('#fUsername').value.trim(),
    password: $('#fPassword').value,
    expiryDate: $('#fExpiry').value || null,
    limit: Number($('#fLimit').value) || 1,
  };
  const errEl = $('#modalError');
  errEl.hidden = true;
  try {
    if (editing) {
      await api(`/users/${encodeURIComponent(editing)}`, { method: 'PUT', body: JSON.stringify(payload) });
      toast(`${editing} updated`);
    } else {
      await api('/users', { method: 'POST', body: JSON.stringify(payload) });
      toast(`${payload.username} created`);
    }
    closeUserModal();
    await renderUsersList();
    renderDashboard();
  } catch (err) {
    errEl.textContent = err.message;
    errEl.hidden = false;
    haptic([10, 30, 10]);
  }
});

// ---------------------------------------------------------------------------
// Logs
// ---------------------------------------------------------------------------
async function loadLogs() {
  const { log } = await api('/logs');
  $('#logOutput').textContent = log && log.trim() ? log : 'No limiter events recorded yet.';
}

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------
$('#genPassBtn').addEventListener('click', async () => {
  const { password } = await api('/generate-password?length=24');
  $('#newPass').value = password;
  haptic(8);
});

$('#passwordForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const msgEl = $('#settingsMsg');
  try {
    await api('/settings/password', {
      method: 'POST',
      body: JSON.stringify({ currentPassword: $('#curPass').value, newPassword: $('#newPass').value }),
    });
    msgEl.textContent = 'Password updated.';
    msgEl.style.color = 'var(--green)';
    $('#passwordForm').reset();
    toast('Password updated');
  } catch (err) {
    msgEl.textContent = err.message;
    msgEl.style.color = 'var(--red)';
    haptic([10, 30, 10]);
  }
});

boot();
