const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

let serverIp = '';
let usersCache = [];

// ---------------------------------------------------------------------------
// Toast
// ---------------------------------------------------------------------------
function toast(msg) {
  const el = $('#toast');
  el.textContent = msg;
  el.hidden = false;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => (el.hidden = true), 2600);
}

// ---------------------------------------------------------------------------
// API helper
// ---------------------------------------------------------------------------
async function api(path, options = {}) {
  const res = await fetch('/api' + path, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  let body = null;
  try { body = await res.json(); } catch {}
  if (!res.ok) throw new Error((body && body.error) || `Request failed (${res.status})`);
  return body;
}

// ---------------------------------------------------------------------------
// Auth / boot
// ---------------------------------------------------------------------------
async function boot() {
  try {
    const { authenticated } = await api('/session');
    if (authenticated) return showApp();
  } catch {}
  showLogin();
}

function showLogin() {
  $('#loginView').hidden = false;
  $('#appView').hidden = true;
}

async function showApp() {
  $('#loginView').hidden = true;
  $('#appView').hidden = false;
  await refreshServerInfo();
  await refreshUsers();
  renderDashboard();
}

$('#loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const password = $('#adminPassword').value;
  const errEl = $('#loginError');
  errEl.hidden = true;
  try {
    await api('/login', { method: 'POST', body: JSON.stringify({ password }) });
    $('#adminPassword').value = '';
    await showApp();
  } catch (err) {
    errEl.textContent = err.message;
    errEl.hidden = false;
  }
});

$('#logoutBtn').addEventListener('click', async () => {
  await api('/logout', { method: 'POST' });
  showLogin();
});

// ---------------------------------------------------------------------------
// Navigation
// ---------------------------------------------------------------------------
$$('.nav-item').forEach((btn) => {
  btn.addEventListener('click', () => switchView(btn.dataset.view));
});
$$('[data-goto]').forEach((btn) => btn.addEventListener('click', () => switchView(btn.dataset.goto)));

function switchView(name) {
  $$('.nav-item').forEach((b) => b.classList.toggle('active', b.dataset.view === name));
  $$('.view').forEach((v) => (v.hidden = v.id !== `view-${name}`));
  if (name === 'logs') loadLogs();
  if (name === 'users') renderUsersTable();
}

// ---------------------------------------------------------------------------
// Server info / dashboard
// ---------------------------------------------------------------------------
async function refreshServerInfo() {
  try {
    const info = await api('/server-info');
    serverIp = info.ip || '—';
    $('#statIp').textContent = serverIp;
    renderServices(info.services);
  } catch {
    $('#statIp').textContent = '—';
  }
}

function renderServices(services = []) {
  $('#serviceList').innerHTML = services
    .map(
      (s) => `<div class="service-item"><span class="dot ${s.active ? 'on' : ''}"></span>${s.label}</div>`
    )
    .join('');
}

async function refreshUsers() {
  const { users } = await api('/users');
  usersCache = users;
}

function renderDashboard() {
  const total = usersCache.length;
  const online = usersCache.filter((u) => u.status === 'online').length;
  const blocked = usersCache.filter((u) => u.status === 'blocked' || u.status === 'expired').length;
  $('#statTotal').textContent = total;
  $('#statOnline').textContent = online;
  $('#statBlocked').textContent = blocked;

  const recent = usersCache.slice(0, 5);
  $('#recentUsers').innerHTML = usersTableHtml(recent, { compact: true });
  bindTableActions($('#recentUsers'));
}

// ---------------------------------------------------------------------------
// Users view
// ---------------------------------------------------------------------------
$('#userSearch').addEventListener('input', () => renderUsersTable());

async function renderUsersTable() {
  await refreshUsers();
  const q = $('#userSearch').value.trim().toLowerCase();
  const filtered = q ? usersCache.filter((u) => u.username.toLowerCase().includes(q)) : usersCache;
  $('#usersTableWrap').innerHTML = usersTableHtml(filtered, { compact: false });
  bindTableActions($('#usersTableWrap'));
}

function statusBadge(u) {
  if (u.status === 'blocked') return '<span class="badge badge-blocked">Blocked</span>';
  if (u.status === 'expired') return '<span class="badge badge-expired">Expired</span>';
  if (u.status === 'online') return '<span class="badge badge-online">Online</span>';
  return '<span class="badge badge-offline">Offline</span>';
}

function connectString(u) {
  const ip = serverIp || 'YOUR.SERVER.IP';
  return `${ip}:1-65535@${u.username}:${u.password || ''}`;
}

function usersTableHtml(users, { compact }) {
  if (!users.length) {
    return `<div class="empty-state">No accounts yet. Click “Add user” to create the first tunnel account.</div>`;
  }
  const rows = users
    .map((u) => {
      const expiry = u.expiryDate ? `${u.expiryDate} (${u.daysLeft >= 0 ? u.daysLeft + 'd left' : 'expired'})` : 'Never';
      const connCol = `${u.connected}${u.limit ? ' / ' + u.limit : ''}`;
      const actions = compact
        ? ''
        : `<div class="row-actions">
            <button class="icon-btn" data-action="view" data-user="${u.username}">Details</button>
            <button class="icon-btn" data-action="edit" data-user="${u.username}">Edit</button>
            ${
              u.status === 'blocked'
                ? `<button class="icon-btn" data-action="unblock" data-user="${u.username}">Unblock</button>`
                : `<button class="icon-btn" data-action="block" data-user="${u.username}">Block</button>`
            }
            <button class="icon-btn danger" data-action="delete" data-user="${u.username}">Delete</button>
          </div>`;
      return `<tr>
        <td class="mono">${u.username}</td>
        <td>${statusBadge(u)}</td>
        <td>${connCol}</td>
        <td>${expiry}</td>
        <td>
          <span class="copy-chip" data-action="copy" data-copy="${connectString(u)}">
            <span class="txt">${connectString(u)}</span>
          </span>
        </td>
        ${compact ? '' : `<td>${actions}</td>`}
      </tr>`;
    })
    .join('');

  return `<table>
    <thead><tr>
      <th>Username</th><th>Status</th><th>Connected</th><th>Expires</th><th>Connect string</th>${compact ? '' : '<th>Actions</th>'}
    </tr></thead>
    <tbody>${rows}</tbody>
  </table>`;
}

function bindTableActions(root) {
  $$('[data-action="copy"]', root).forEach((el) =>
    el.addEventListener('click', () => copyToClipboard(el.dataset.copy))
  );
  $$('[data-action="view"]', root).forEach((el) =>
    el.addEventListener('click', () => openDetail(el.dataset.user))
  );
  $$('[data-action="edit"]', root).forEach((el) =>
    el.addEventListener('click', () => openUserModal(el.dataset.user))
  );
  $$('[data-action="block"]', root).forEach((el) =>
    el.addEventListener('click', () => toggleBlock(el.dataset.user, true))
  );
  $$('[data-action="unblock"]', root).forEach((el) =>
    el.addEventListener('click', () => toggleBlock(el.dataset.user, false))
  );
  $$('[data-action="delete"]', root).forEach((el) =>
    el.addEventListener('click', () => deleteUser(el.dataset.user))
  );
}

function copyToClipboard(text) {
  navigator.clipboard
    .writeText(text)
    .then(() => toast('Copied to clipboard'))
    .catch(() => toast('Could not copy — select and copy manually'));
}

async function toggleBlock(username, block) {
  try {
    await api(`/users/${encodeURIComponent(username)}/${block ? 'block' : 'unblock'}`, { method: 'POST' });
    toast(block ? `${username} blocked` : `${username} unblocked`);
    await renderUsersTable();
    renderDashboard();
  } catch (err) {
    toast(err.message);
  }
}

async function deleteUser(username) {
  if (!confirm(`Delete account "${username}"? This cannot be undone.`)) return;
  try {
    await api(`/users/${encodeURIComponent(username)}`, { method: 'DELETE' });
    toast(`${username} deleted`);
    await renderUsersTable();
    renderDashboard();
  } catch (err) {
    toast(err.message);
  }
}

// ---------------------------------------------------------------------------
// Detail modal
// ---------------------------------------------------------------------------
function openDetail(username) {
  const u = usersCache.find((x) => x.username === username);
  if (!u) return;
  const expiry = u.expiryDate ? `${u.expiryDate} (${u.daysLeft >= 0 ? u.daysLeft + ' days left' : 'expired'})` : 'Never';
  $('#detailBody').innerHTML = `
    <div class="row"><span>Username</span><span>${u.username}</span></div>
    <div class="row"><span>Password</span><span>${u.password || '—'}</span></div>
    <div class="row"><span>Status</span><span>${statusBadge(u)}</span></div>
    <div class="row"><span>Connections</span><span>${u.connected} / ${u.limit || '∞'}</span></div>
    <div class="row"><span>Expires</span><span>${expiry}</span></div>
    <div class="row"><span>Connect string</span></div>
    <span class="copy-chip" data-action="copy" data-copy="${connectString(u)}" style="width:100%;margin-top:6px">
      <span class="txt">${connectString(u)}</span>
    </span>
  `;
  bindTableActions($('#detailBody'));
  $('#detailModal').hidden = false;
}
$('#closeDetailModal').addEventListener('click', () => ($('#detailModal').hidden = true));
$('#detailModal').addEventListener('click', (e) => {
  if (e.target.id === 'detailModal') $('#detailModal').hidden = true;
});

// ---------------------------------------------------------------------------
// Add / edit user modal
// ---------------------------------------------------------------------------
$('#openAddUser').addEventListener('click', () => openUserModal(null));
$('#closeModal').addEventListener('click', closeUserModal);
$('#cancelUserBtn').addEventListener('click', closeUserModal);
$('#userModal').addEventListener('click', (e) => {
  if (e.target.id === 'userModal') closeUserModal();
});

function openUserModal(username) {
  const editing = !!username;
  $('#modalTitle').textContent = editing ? `Edit ${username}` : 'Add user';
  $('#editUsername').value = username || '';
  $('#fUsername').value = username || '';
  $('#fUsername').disabled = editing;
  $('#modalError').hidden = true;

  if (editing) {
    const u = usersCache.find((x) => x.username === username);
    $('#fPassword').value = u.password || '';
    $('#fExpiry').value = u.expiryDate || '';
    $('#fLimit').value = u.limit || 1;
  } else {
    $('#fPassword').value = '';
    $('#fExpiry').value = '';
    $('#fLimit').value = 1;
  }
  $('#userModal').hidden = false;
}

function closeUserModal() {
  $('#userModal').hidden = true;
  $('#userForm').reset();
  $('#fUsername').disabled = false;
}

$('#fGenPass').addEventListener('click', async () => {
  const { password } = await api('/generate-password?length=20');
  $('#fPassword').value = password;
});

$('#userForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const editing = $('#editUsername').value;
  const payload = {
    username: $('#fUsername').value.trim(),
    password: $('#fPassword').value,
    expiryDate: $('#fExpiry').value || null,
    limit: Number($('#fLimit').value) || 1,
  };
  const errEl = $('#modalError');
  errEl.hidden = true;
  try {
    if (editing) {
      await api(`/users/${encodeURIComponent(editing)}`, { method: 'PUT', body: JSON.stringify(payload) });
      toast(`${editing} updated`);
    } else {
      await api('/users', { method: 'POST', body: JSON.stringify(payload) });
      toast(`${payload.username} created`);
    }
    closeUserModal();
    await renderUsersTable();
    renderDashboard();
  } catch (err) {
    errEl.textContent = err.message;
    errEl.hidden = false;
  }
});

// ---------------------------------------------------------------------------
// Logs
// ---------------------------------------------------------------------------
async function loadLogs() {
  const { log } = await api('/logs');
  $('#logOutput').textContent = log && log.trim() ? log : 'No limiter events recorded yet.';
}

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------
$('#genPassBtn').addEventListener('click', async () => {
  const { password } = await api('/generate-password?length=24');
  $('#newPass').value = password;
});

$('#passwordForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const msgEl = $('#settingsMsg');
  try {
    await api('/settings/password', {
      method: 'POST',
      body: JSON.stringify({ currentPassword: $('#curPass').value, newPassword: $('#newPass').value }),
    });
    msgEl.textContent = 'Password updated.';
    msgEl.style.color = 'var(--green)';
    $('#passwordForm').reset();
  } catch (err) {
    msgEl.textContent = err.message;
    msgEl.style.color = 'var(--red)';
  }
});

boot();
